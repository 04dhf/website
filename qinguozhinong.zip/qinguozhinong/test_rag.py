# -*- coding: utf-8 -*-
"""验证 RAG 流程：重新加载资料 → 提问 → 检查参考来源展示。"""
import re
import requests

s = requests.Session()

# 1. 重新加载资料
r = s.post("http://127.0.0.1:8080/reload", timeout=30, allow_redirects=True)
print("reload 状态码:", r.status_code)
print("reload 提示:", re.findall(r"✅ (.*?)</p>", r.text))

# 2. 提问（命中导入的苹果储存文档）
r2 = s.post("http://127.0.0.1:8080/consult",
            data={"question": "苹果怎么储存保鲜"}, timeout=60)
html = r2.text
print("\nconsult 状态码:", r2.status_code)
print("有参考来源区:", 'class="rag-sources card"' in html)
print("来源编号:", re.findall(r'rag-sid">(.*?)</span>', html))
print("来源文档:", re.findall(r'rag-doc">(.*?)</span>', html))
print("资料未导入提示:", "外部资料尚未导入" in html)

# 3. 提问（不命中文档的问题，验证来源区不显示）
r3 = s.post("http://127.0.0.1:8080/consult",
            data={"question": "什么是人工智能"}, timeout=60)
html3 = r3.text
print("\n无关问题 consult 状态码:", r3.status_code)
print("无关问题无参考来源区:", 'class="rag-sources card"' not in html3)

# 4. 知识库页显示导入文档
r4 = s.get("http://127.0.0.1:8080/knowledge", timeout=30)
html4 = r4.text
print("\nknowledge 状态码:", r4.status_code)
print("显示导入文档列表:", "已导入的外部资料" in html4)
print("显示文档标题:", "苹果储存保鲜实用指南" in html4)
print("显示来源编号:", "SRC-2026-001" in html4)
print("显示重新加载按钮:", "重新加载资料" in html4)
print("统计信息:", re.findall(r"已导入文档 <b>(\d+)</b> 篇，行情 CSV <b>(\d+)</b> 条", html4))