# -*- coding: utf-8 -*-
"""验证 _filter_history_for_question 的四类场景。"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from app import (
    _filter_history_for_question,
    _has_reference_word,
    _is_topic_continuation,
)

passed = 0
failed = 0


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print("  [PASS] %s" % name)
    else:
        failed += 1
        print("  [FAIL] %s %s" % (name, detail))


print("=" * 60)
print("场景1：话题切换（苹果气调 → 猕猴桃催熟）")
print("=" * 60)
q1 = "富士商业气调氧气2%—4%、二氧化碳1%—3%对吗？"
a1 = "根据参考资料，富士系商业气调参考为氧气3%—5%、二氧化碳0%—2%..."
q2 = "所有陕西猕猴桃都能按上海案例3天变甜吗？"
history1 = [
    {"role": "user", "content": q1},
    {"role": "assistant", "content": a1},
]
filtered1 = _filter_history_for_question(q2, history1)
check("话题切换时history应为空", len(filtered1) == 0,
      "实际长度=%d" % len(filtered1))
check("话题连续性判定应为False", not _is_topic_continuation(q2, q1))
check("猕猴桃问题不含指代词", not _has_reference_word(q2))

print()
print("=" * 60)
print("场景2：正常追问（80mm价格 → '那75mm的呢'）")
print("=" * 60)
q3 = "2026年1月80mm富士批发均价多少"
a3 = "4.89元/斤..."
q4 = "那75mm的呢"
history2 = [
    {"role": "user", "content": q3},
    {"role": "assistant", "content": a3},
]
filtered2 = _filter_history_for_question(q4, history2)
check("追问时history应保留最近1轮", len(filtered2) == 2,
      "实际长度=%d" % len(filtered2))
check("追问含指代词'那'", _has_reference_word(q4) or "那" in q4)

print()
print("=" * 60)
print("场景3：同话题连续（80mm → 75mm/85mm/90mm价格）")
print("=" * 60)
q5 = "2026年1月75mm、85mm、90mm富士均价是多少？"
history3 = [
    {"role": "user", "content": q3},
    {"role": "assistant", "content": a3},
]
filtered3 = _filter_history_for_question(q5, history3)
check("同话题history应保留", len(filtered3) == 2,
      "实际长度=%d" % len(filtered3))
check("话题连续性判定应为True", _is_topic_continuation(q5, q3))

print()
print("=" * 60)
print("场景4：指代词场景（T20：'把你前面说的价格换成元/公斤'）")
print("=" * 60)
q6 = "把你前面说的2026年1月价格换成元/公斤"
history4 = [
    {"role": "user", "content": q3},
    {"role": "assistant", "content": a3},
]
filtered4 = _filter_history_for_question(q6, history4)
check("指代词场景history应保留", len(filtered4) == 2,
      "实际长度=%d" % len(filtered4))
check("含指代词'前面'", _has_reference_word(q6))

print()
print("=" * 60)
print("场景5：多轮混合（苹果价格→猕猴桃→又问苹果规格）")
print("=" * 60)
q7 = "猕猴桃出库价是多少"
a7 = "2.3—5.5元/斤..."
q8 = "2026年1月85mm富士批发均价是多少？"
history5 = [
    {"role": "user", "content": q3},
    {"role": "assistant", "content": a3},
    {"role": "user", "content": q7},
    {"role": "assistant", "content": a7},
]
filtered5 = _filter_history_for_question(q8, history5)
# q8与q3话题相关（富士价格），但中间隔了q7（猕猴桃），从最近往前遇到q7不相关应停止
check("中间隔了无关轮次应停止追溯", len(filtered5) == 0,
      "实际长度=%d" % len(filtered5))

print()
print("=" * 60)
print("场景6：连续同话题多轮（价格→价格→价格）")
print("=" * 60)
q9 = "2026年1月90mm富士批发均价是多少？"
a9 = "5.51元/斤..."
history6 = [
    {"role": "user", "content": q3},
    {"role": "assistant", "content": a3},
    {"role": "user", "content": q5},
    {"role": "assistant", "content": "4.14、5.32、5.51元/斤..."},
]
filtered6 = _filter_history_for_question(q9, history6)
# q9与最近轮q5相关，q5与q3也相关，应保留全部
check("连续同话题应保留全部历史", len(filtered6) == 4,
      "实际长度=%d" % len(filtered6))

print()
print("=" * 60)
print("场景7：无历史（第一轮提问）")
print("=" * 60)
filtered7 = _filter_history_for_question(q1, [])
check("无历史应返回空列表", len(filtered7) == 0)

print()
print("=" * 60)
print("总计：%d 通过，%d 失败" % (passed, failed))
print("=" * 60)
sys.exit(1 if failed else 0)