# -*- coding: utf-8 -*-
"""快速检查：Markdown渲染 + 来源卡 + 回答内容"""
import re
import requests

s = requests.Session()
r = s.post('http://127.0.0.1:8080/consult',
           data={'question': '苹果商业贮藏气调参数是什么'}, timeout=60)
t = r.text

# 提取助手回答（去标签后显示前500字）
m = re.search(r'bubble-assistant[^>]*>(.*?)</div>\s*</div>', t, re.S)
if m:
    plain = re.sub(r'<[^>]+>', ' ', m.group(1)).strip()
    print('ANSWER:', plain[:500])
else:
    print('ANSWER: NOT FOUND')

# 来源卡
sids = re.findall(r'rag-sid">(QG_[A-Z0-9]+)</span>', t)
flags = re.findall(r'rag-flag[^"]*">([^<]+)</span>', t)
print('SOURCES:', sids)
print('FLAGS:', flags)
print('HAS_CITED_FLAG:', '正文引用' in t)
print('HAS_CANDIDATE_FLAG:', '检索候选' in t)