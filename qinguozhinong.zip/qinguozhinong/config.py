# -*- coding: utf-8 -*-
"""
秦果知农 - 大模型 API 配置
==========================
⚠️ 本文件包含 API 密钥，已被 .gitignore 排除，不会提交到代码仓库。
⚠️ 请勿将本文件内容分享给他人或截图展示。

接入的大模型信息：
- API 地址：https://open.bigmodel.cn/api/paas/v4/
- 模型名称：glm-5.3-flash
"""

# 大模型 API 配置
LLM_API_URL = "https://open.bigmodel.cn/api/paas/v4/"
LLM_API_KEY = "c45f82ac16a24f55a0eaea16e1a22af7.lfFJ8iu6KbjnOhys"
LLM_MODEL_NAME = "glm-5.3-flash"

# 请求超时时间（秒），防止API响应过慢导致页面卡死
LLM_TIMEOUT = 30