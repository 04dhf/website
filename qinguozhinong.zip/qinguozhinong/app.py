# -*- coding: utf-8 -*-
"""
秦果知农 - 主程序
=================
这是整个网站的"大门"。用户在浏览器里看到的每一个页面，
都由这个文件里的代码负责接待。

阶段2：首页 + 知识库 + 关键词咨询，数据来自 data/knowledge.json。
"""

import csv
import html
import json
import os
import re

import requests
from flask import Flask, render_template, request, session, flash, redirect, url_for

import config

# 创建 Flask 应用实例
# __name__ 是 Python 的内置变量，告诉 Flask 当前文件的位置，
# 这样它才能找到 templates（网页模板）和 static（图片/样式）文件夹
app = Flask(__name__)

# Flask session 加密密钥：用于多轮对话的会话隔离
# 每个浏览器的 cookie 不同，不同用户的对话历史互不可见
app.secret_key = "qinguozhinong-secret-2026"


# ============================================================
# Markdown 安全渲染（阶段6新增）
# ============================================================

def render_markdown_safe(text):
    """
    将 Markdown 文本安全渲染为 HTML，供对话气泡使用。

    安全策略（两步走）：
    1. 先对全文做 HTML 转义（< > & " 全部变成实体），这样模型输出的
       任何原始 HTML 标签都会被当成普通文字显示，绝不会被浏览器执行；
    2. 再在转义后的文本上解析 Markdown 语法，生成的标签都是我们自己
       拼的，不存在注入风险。

    支持的语法：标题(# ~ ####)、加粗**、斜体*、无序列表(- *)、
    有序列表(1.)、表格(| a | b |)、链接[text](url)、行内代码`code`、
    段落换行。

    链接白名单：只渲染 http:// 和 https:// 开头的链接，
    其他协议（javascript: 等）原样显示，不生成可点击链接。
    """
    if not text:
        return ""

    # ---- 第1步：HTML 转义，杜绝 XSS 和模型 HTML 注入 ----
    s = html.escape(text)

    lines = s.split("\n")
    out = []
    in_ul = False   # 是否正在写无序列表
    in_ol = False   # 是否正在写有序列表
    in_table = False  # 是否正在写表格
    table_rows = []   # 表格行缓存

    def close_lists():
        """关闭打开的列表标签"""
        nonlocal in_ul, in_ol
        if in_ul:
            out.append("</ul>")
            in_ul = False
        if in_ol:
            out.append("</ol>")
            in_ol = False

    def flush_table():
        """把缓存的表格行拼成 <table> 输出"""
        nonlocal in_table, table_rows
        if in_table and table_rows:
            out.append('<table class="md-table">')
            for ri, row in enumerate(table_rows):
                out.append("<tr>")
                # 第一行作为表头 <th>，其余为 <td>
                tag = "th" if ri == 0 else "td"
                for cell in row:
                    out.append("<%s>%s</%s>" % (tag, cell, tag))
                out.append("</tr>")
            out.append("</table>")
        in_table = False
        table_rows = []

    for line in lines:
        stripped = line.strip()

        # 空行：关闭列表和表格（段落分隔）
        if not stripped:
            close_lists()
            flush_table()
            continue

        # 表格行：以 | 开头且以 | 结尾
        if stripped.startswith("|") and stripped.endswith("|"):
            close_lists()
            cells = [c.strip() for c in stripped.strip("|").split("|")]
            # 跳过分隔行（如 |---|---|），它只用来标记表头
            if cells and all(re.match(r"^:?-{2,}:?$", c) for c in cells if c):
                continue
            in_table = True
            table_rows.append(cells)
            continue
        # 不是表格行就先把表格输出掉
        flush_table()

        # 标题：# ~ ####（气泡内空间小，统一降两级：# → h3）
        m = re.match(r"^(#{1,4})\s+(.*)", stripped)
        if m:
            close_lists()
            level = min(len(m.group(1)) + 2, 6)
            out.append("<h%d class='md-h'>%s</h%d>" % (level, m.group(2), level))
            continue

        # 无序列表：- xxx 或 * xxx
        m = re.match(r"^[-*]\s+(.*)", stripped)
        if m:
            if in_ol:
                out.append("</ol>")
                in_ol = False
            if not in_ul:
                out.append("<ul class='md-list'>")
                in_ul = True
            out.append("<li>%s</li>" % m.group(1))
            continue

        # 有序列表：1. xxx 或 1、xxx
        m = re.match(r"^\d+[.、]\s+(.*)", stripped)
        if m:
            if in_ul:
                out.append("</ul>")
                in_ul = False
            if not in_ol:
                out.append("<ol class='md-list'>")
                in_ol = True
            out.append("<li>%s</li>" % m.group(1))
            continue

        # 普通段落
        close_lists()
        out.append("<p class='md-p'>%s</p>" % stripped)

    # 收尾：关闭可能还开着的列表和表格
    close_lists()
    flush_table()

    html_out = "\n".join(out)

    # ---- 行内格式（在转义后的文本上处理，安全）----
    # 加粗 **xxx**
    html_out = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", html_out)
    # 斜体 *xxx*（避免误伤列表标记，要求*紧贴文字）
    html_out = re.sub(r"(?<!\*)\*([^*\n]+?)\*(?!\*)", r"<em>\1</em>", html_out)
    # 行内代码 `xxx`
    html_out = re.sub(r"`([^`]+)`", r"<code class='md-code'>\1</code>", html_out)
    # 链接 [text](url) —— 只允许 http/https 协议
    def _link_repl(m):
        url = m.group(2)
        if re.match(r"^https?://", url):
            return ('<a class="md-link" href="%s" target="_blank" rel="noopener">%s</a>'
                    % (url, m.group(1)))
        return m.group(0)  # 非 http 链接原样显示，不生成可点击链接
    html_out = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", _link_repl, html_out)

    return html_out


# 注册为 Jinja2 模板过滤器，模板里用 {{ msg.content | md_render | safe }}
app.jinja_env.filters["md_render"] = render_markdown_safe

# 知识库数据文件的路径（os.path.dirname 拿到当前文件所在目录，
# 再拼上 data/knowledge.json，这样无论从哪里启动程序都能找到文件）
KNOWLEDGE_FILE = os.path.join(os.path.dirname(__file__), "data", "knowledge.json")
# 行情数据文件的路径（阶段3新增）
MARKET_FILE = os.path.join(os.path.dirname(__file__), "data", "market.json")


def load_knowledge():
    """读取知识库 JSON 文件，返回苹果和猕猴桃的知识列表"""
    with open(KNOWLEDGE_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("apple", []), data.get("kiwi", [])


def load_market():
    """
    读取行情 JSON 文件，返回页面需要的四部分数据：
    - apple_market    ：苹果行情列表
    - kiwi_market     ：猕猴桃行情列表
    - industry_facts  ：产业背景事实列表
    - update_date     ：数据整理日期
    """
    with open(MARKET_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return (
        data.get("apple_market", []),
        data.get("kiwi_market", []),
        data.get("industry_facts", []),
        data.get("数据整理日期", ""),
    )


# ============================================================
# 外部资料导入与检索（Markdown 科普文档 + CSV 行情表）
# ============================================================
# 资料目录：Markdown 文档放 data/docs/，行情 CSV 放 data/market_csv/
# 文件名以 _ 开头的是格式说明，不会被导入

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
DOCS_DIR = os.path.join(DATA_DIR, "docs")
MARKET_CSV_DIR = os.path.join(DATA_DIR, "market_csv")

# 全局资料缓存：reload_all_data() 每次先清空再装填，重复加载不产生重复记录
DOC_CHUNKS = []       # 文档切分后的检索块（每块含完整来源元数据）
DOCS_META = []        # 文档元数据列表（供知识库页展示）
CSV_MARKET_ROWS = []  # CSV 行情行（已适配行情页字段格式）


def _parse_front_matter(text):
    """
    解析 Markdown 开头的 YAML front matter（简单 key: value 格式）。

    格式：
        ---
        source_id: SRC-001
        title: 标题
        ---
        正文...

    返回 (元数据字典, 去掉头部后的正文)；没有 front matter 时返回 ({}, 原文)。
    不依赖 PyYAML，自己解析简单的键值对。
    """
    if not text.startswith("---"):
        return {}, text
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}, text
    meta = {}
    for line in parts[1].strip().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        key, _, value = line.partition(":")
        meta[key.strip()] = value.strip().strip('"').strip("'")
    # 字段名映射：外部资料包使用 url/publish_date/scenario，
    # 统一映射到内部名称 source_url/date/scene（原有文件不受影响）
    if "url" in meta and "source_url" not in meta:
        meta["source_url"] = meta["url"]
    if "publish_date" in meta and "date" not in meta:
        meta["date"] = meta["publish_date"]
    if "scenario" in meta and "scene" not in meta:
        meta["scene"] = meta["scenario"]
    return meta, parts[2].lstrip("\n")


def _char_ngrams(text, n=2):
    """
    中文检索用的字符 n-gram：把文本拆成相邻 n 个字符的集合。

    不依赖分词库，对中文短句检索效果好：
    "洛川苹果" → {"洛川", "川苹", "苹果"}
    """
    cleaned = re.sub(r"[\s\d，。、！？；：“”‘’（）《》【】·#\-\*\.\,\!\?\;\:\"\']+", "", text)
    return set(cleaned[i:i + n] for i in range(max(0, len(cleaned) - n + 1)))


def _split_markdown(body, meta):
    """
    将文档正文切分成检索块（chunk），每块都带完整来源元数据。

    切分规则：
    - 优先按二级标题（## ）切分，每个小节是一个块
    - 没有二级标题时，按空行分段，累积到约 500 字合并成块
    - 切分时预计算每块的字符 2-gram 集合，检索时直接比对，速度快
    """
    chunks = []
    sections = re.split(r"(?m)^##\s+", body)
    if len(sections) > 1:
        intro = sections[0].strip()
        if intro:
            chunks.append({"section": "概述", "text": intro})
        for sec in sections[1:]:
            lines = sec.strip().splitlines()
            sec_title = lines[0].strip() if lines else "正文"
            sec_text = "\n".join(lines[1:]).strip() if len(lines) > 1 else ""
            if sec_text:
                chunks.append({"section": sec_title, "text": sec_text})
    else:
        paragraphs = [p.strip() for p in body.split("\n\n") if p.strip()]
        buf = ""
        for para in paragraphs:
            if buf and len(buf) + len(para) > 500:
                chunks.append({"section": "正文", "text": buf})
                buf = para
            else:
                buf = (buf + "\n" + para).strip()
        if buf:
            chunks.append({"section": "正文", "text": buf})

    result = []
    for c in chunks:
        chunk = {
            "source_id": meta.get("source_id", ""),
            "title": meta.get("title", ""),
            "publisher": meta.get("publisher", ""),
            "source_url": meta.get("source_url", ""),
            "date": meta.get("date", ""),
            "product": meta.get("product", ""),
            "scene": meta.get("scene", ""),
            "section": c["section"],
            "text": c["text"],
        }
        # 预计算检索用 2-gram（内部字段，不传给模板）
        chunk["_grams"] = _char_ngrams(chunk["title"] + c["section"] + c["text"])
        result.append(chunk)
    return result


def import_docs():
    """
    扫描 data/docs/ 下所有 .md 文件（_ 开头的跳过），解析元数据并切分。

    去重：同一 source_id 只保留一份（后读取的覆盖先读取的）。
    每次调用先清空缓存，重复加载不会产生重复记录。
    返回导入的文档篇数。
    """
    global DOC_CHUNKS, DOCS_META
    DOC_CHUNKS = []
    DOCS_META = []
    if not os.path.isdir(DOCS_DIR):
        return 0

    doc_map = {}  # 按 source_id 去重
    for fname in sorted(os.listdir(DOCS_DIR)):
        if not fname.lower().endswith(".md") or fname.startswith("_"):
            continue
        fpath = os.path.join(DOCS_DIR, fname)
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                text = f.read()
        except (OSError, UnicodeDecodeError) as e:
            print("[import_docs] 跳过无法读取的文件 %s：%s" % (fname, e))
            continue
        meta, body = _parse_front_matter(text)
        if not meta.get("source_id"):
            print("[import_docs] 跳过缺少 source_id 的文件 %s" % fname)
            continue
        doc_map[meta["source_id"]] = (meta, body)

    for source_id, (meta, body) in doc_map.items():
        DOCS_META.append(dict(meta))
        DOC_CHUNKS.extend(_split_markdown(body, meta))
    return len(doc_map)


def import_market_csv():
    """
    扫描 data/market_csv/ 下所有 .csv 文件（_ 开头的跳过），导入行情数据。

    必需字段（表头）：source_id,product,variety,grade,region,stage,date,price,unit
    去重：按整行内容指纹去重，同一行数据多次导入只保留一条。
    每次调用先清空缓存。返回导入的行情条数。
    """
    global CSV_MARKET_ROWS
    CSV_MARKET_ROWS = []
    if not os.path.isdir(MARKET_CSV_DIR):
        return 0

    seen = set()  # 整行指纹去重
    for fname in sorted(os.listdir(MARKET_CSV_DIR)):
        if not fname.lower().endswith(".csv") or fname.startswith("_"):
            continue
        fpath = os.path.join(MARKET_CSV_DIR, fname)
        try:
            with open(fpath, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    fields = [(row.get(k, "") or "").strip()
                              for k in ("source_id", "product", "variety",
                                        "grade", "region", "stage",
                                        "date", "price", "unit")]
                    fingerprint = "|".join(fields)
                    if not fingerprint.replace("|", "") or fingerprint in seen:
                        continue
                    seen.add(fingerprint)
                    product = fields[0 + 1]  # product 列
                    CSV_MARKET_ROWS.append({
                        "id": "csv_%d" % (len(CSV_MARKET_ROWS) + 1),
                        "category": fields[5],       # stage → 价格环节
                        "product": fields[2] or product,  # variety 优先展示
                        "origin": fields[4],          # region
                        "spec": fields[3],            # grade
                        "price": "%s %s" % (fields[7], fields[8]),  # "3.5 元/斤"
                        "price_note": "来源编号：%s" % fields[0],
                        "date": fields[6],
                        "source": "外部资料包（%s）" % fields[0],
                        "source_url": "",
                        "interpretation": "",
                        "_type": "apple" if "苹果" in product else "kiwi",
                    })
        except (OSError, UnicodeDecodeError) as e:
            print("[import_market_csv] 跳过无法读取的文件 %s：%s" % (fname, e))
    return len(CSV_MARKET_ROWS)


def reload_all_data():
    """重新加载全部外部资料（文档 + CSV 行情），返回统计信息。"""
    docs_count = import_docs()
    csv_count = import_market_csv()
    print("[reload] 资料加载完成：文档 %d 篇（%d 个检索块），行情 CSV %d 条"
          % (docs_count, len(DOC_CHUNKS), csv_count))
    return {"docs": docs_count, "chunks": len(DOC_CHUNKS), "csv_rows": csv_count}


# 同义词扩展表：用户口语 → 文档用语
# 2-gram 检索对同义词无能为力（"长了霉"≠"霉烂"），检索前把口语词
# 补充为文档中实际使用的词语，提高召回率，不改变原有得分逻辑。
_SYNONYM_EXPAND = {
    # 变质/霉烂
    "霉": "霉烂 霉菌 腐烂 变质 丢弃",
    "变质": "霉烂 腐烂 丢弃",
    "腐烂": "霉烂 霉菌 丢弃",
    # 保存
    "多放": "保存 冷藏 保鲜 延缓",
    "放几天": "保存 冷藏 保鲜",
    "保存": "冷藏 保鲜 分开",
    "储存": "冷藏 保鲜",
    "储藏": "冷藏 气调",
    "贮藏": "冷藏 气调",
    # 混装/分开
    "一起装": "分开 乙烯 释放",
    "一起放": "分开 乙烯 释放",
    "混装": "分开 乙烯",
    # 催熟
    "催熟": "乙烯 软化 成熟",
    # 果蜡
    "果蜡": "食用蜡 工业蜡 天然",
    # 口感
    "绵软": "口感 花牛 软",
    "脆甜": "口感 嘎啦 紧实",
    # 价格
    "均价": "批发 监测 汇总",
    "报价": "批发 市场 行情",
    "走势": "趋势 连续 断档",
    "什么价": "价格 报价 行情",
    "多少钱": "价格 报价 行情",
    # 标准
    "条文": "正文 条款 目录",
}


def _expand_question(question):
    """同义词扩展：若问题包含上表中的口语词，补充对应文档用语再检索"""
    extra = []
    for key, vals in _SYNONYM_EXPAND.items():
        if key in question:
            extra.append(vals)
    if extra:
        return question + " " + " ".join(extra)
    return question


def search_docs(question, top_k=5, min_score=2):
    """
    在导入的文档块中检索与问题相关的内容（中文字符 2-gram 匹配）。

    - 检索前先做同义词扩展，弥补"长了霉"与"霉烂"这类字面差异
    - 得分 = 扩展后问题 2-gram 集合与块 2-gram 集合的交集大小
    - 只返回得分 ≥ min_score 的块，按得分降序，最多 top_k 个
    - 每块含完整来源元数据（source_id/title/publisher/source_url/date 等）
    - 没有导入资料时返回空列表
    """
    if not DOC_CHUNKS:
        return []
    q_grams = _char_ngrams(_expand_question(question))
    if not q_grams:
        return []
    scored = []
    for chunk in DOC_CHUNKS:
        score = len(q_grams & chunk["_grams"])
        if score >= min_score:
            scored.append((score, chunk))
    scored.sort(key=lambda x: x[0], reverse=True)
    # 返回时去掉内部的 _grams 字段
    return [{k: v for k, v in c.items() if k != "_grams"} for _, c in scored[:top_k]]


# 路由（route）：把"网址"和"函数"绑定在一起
# '@app.route("/")' 的意思是：当用户访问首页（/）时，执行下面的函数
@app.route("/")
def index():
    """首页：项目介绍 + 三个功能入口卡片"""
    # render_template 会去 templates 文件夹找对应的 HTML 文件并渲染
    # active_page 用来告诉导航栏当前高亮哪个标签
    return render_template("index.html", active_page="index")


@app.route("/knowledge")
def knowledge():
    """知识库页：展示科普知识（JSON 知识库 + 导入的 Markdown 文档）"""
    apple_items, kiwi_items = load_knowledge()
    return render_template(
        "knowledge.html",
        active_page="knowledge",
        apple_items=apple_items,
        kiwi_items=kiwi_items,
        docs_meta=DOCS_META,
        csv_rows_count=len(CSV_MARKET_ROWS),
    )


# ============================================================
# 阶段2：知识咨询（关键词匹配版）
# ============================================================

def search_knowledge(question):
    """
    在知识库中检索与用户问题相关的知识条目。

    匹配规则（简单关键词匹配，新手易懂）：
    1. 遍历每条知识的 keywords 列表
    2. 只要用户的问题里"包含"任何一个关键词，就算命中
    3. 命中的关键词越多，排得越靠前（按命中数量降序）
    """
    apple_items, kiwi_items = load_knowledge()
    results = []

    # 把苹果和猕猴桃的知识统一处理，type 字段标记来源
    all_items = (
        [{"type": "apple", "type_label": "🍎 苹果", **item} for item in apple_items]
        + [{"type": "kiwi", "type_label": "🥝 猕猴桃", **item} for item in kiwi_items]
    )

    for item in all_items:
        # 统计这条知识命中了几个关键词
        hit_count = 0
        for keyword in item.get("keywords", []):
            if keyword in question:
                hit_count += 1
        # 命中至少 1 个关键词才加入结果
        if hit_count > 0:
            results.append({**item, "hit_count": hit_count})

    # 按命中数量从多到少排序，命中最多的排最前
    results.sort(key=lambda x: x["hit_count"], reverse=True)
    return results


def ask_llm(question, history=None, context=None):
    """
    调用大模型 API 获取智能回答。

    参数：
    - question ：用户本轮问题
    - history  ：之前的对话历史，格式 [{"role": "user/assistant", "content": "..."}]
                 传入后模型能理解上下文（多轮对话）
    - context  ：检索到的参考资料文本（RAG），传入后模型优先根据资料回答

    配置在 config.py 中（API地址、密钥、模型名）。
    调用失败时返回 None，页面自动回退到关键词搜索结果。

    安全注意：密钥从 config.py 读取，不硬编码在本文件中，
    也不会出现在任何页面或日志输出中。
    """
    # 系统提示词：定义助手角色和行为边界
    system_prompt = (
        "你是「秦果知农」智能助手，专注于陕西苹果和猕猴桃领域。"
        "你的服务对象是果农和消费者。"
        "回答要求："
        "1. 用通俗易懂的中文回答，直接给出答案内容，"
        "不要用'您好''根据参考资料'等套话开头；"
        "2. 只回答与苹果、猕猴桃、农业种植、储存、行情相关的问题；"
        "3. 不编造具体价格数据，涉及价格时提醒用户以实际市场行情为准；"
        "4. 不做价格预测，不提供交易建议；"
        "5. 如果问题超出你的知识范围，诚实告知；"
        "6. 如果提供了参考资料，优先根据资料回答，"
        "引用资料时在句末标注对应编号（如[1]、[2]）；"
        "资料中没有的内容基于通用知识回答并说明；"
        "7. 不要编造资料中不存在的链接、数据或来源；"
        "8. 简单问价类问题控制在150—250字以内，直接给出数字和口径；"
        "复杂问题按需展开，但不堆砌无关内容，不截断必要条件；"
        "9. 不要提及任何开发过程、历史版本、参数修改等内部信息，"
        "面向用户只说当前结论。"
    )

    # 组装完整消息列表：system + 参考资料 + 历史对话 + 本轮问题
    messages = [{"role": "system", "content": system_prompt}]
    if context:
        messages.append({"role": "system", "content": "【参考资料】\n" + context})
    if history:
        messages.extend(history)
    messages.append({"role": "user", "content": question})

    try:
        response = requests.post(
            config.LLM_API_URL.rstrip("/") + "/chat/completions",
            headers={
                "Authorization": "Bearer " + config.LLM_API_KEY,
                "Content-Type": "application/json",
            },
            json={
                "model": config.LLM_MODEL_NAME,
                "messages": messages,
            },
            timeout=config.LLM_TIMEOUT,
        )
        response.raise_for_status()
        data = response.json()
        # 从标准 OpenAI 兼容格式中提取回答文本
        return data["choices"][0]["message"]["content"]
    except requests.exceptions.Timeout:
        print("[ask_llm] 请求超时")
        return None
    except requests.exceptions.ConnectionError:
        print("[ask_llm] 无法连接到模型服务")
        return None
    except requests.exceptions.HTTPError as e:
        # 不输出具体错误详情，避免泄露敏感信息
        print("[ask_llm] 模型服务返回错误，状态码：", e.response.status_code)
        return None
    except (KeyError, IndexError, ValueError) as e:
        print("[ask_llm] 解析模型响应失败")
        return None


# 大模型已配置：API地址、密钥、模型名在 config.py 中
LLM_CONFIGURED = True


# 对话历史最多保留的轮数（1轮 = 1问1答 = 2条消息）
# 防止session过大和token超限
MAX_HISTORY_TURNS = 10


# 指代/回指表达：问题中出现这些词时，说明用户在追问上一轮内容，
# 需要保留最近历史让模型理解指代对象
_REFERENCE_WORDS = (
    "刚才", "刚刚", "前面", "上面", "之前", "上次",
    "你说的", "你提到", "你回答", "你答",
    "那个", "这个", "那", "它们", "上文", "前文",
)


def _has_reference_word(question):
    """检测问题是否包含指代上一轮的回指表达（如'刚才''那个'）。"""
    return any(word in question for word in _REFERENCE_WORDS)


# 通用问句成分：计算话题相关性前先去除，避免"是多少""多少钱"等
# 万能句式让无关问题被误判为话题连续
_GENERIC_QUESTION_PATTERNS = re.compile(
    r"(是多少|多少钱|怎么办|是什么|怎么样|对吗|对不对|能不能|可以吗|呢|吗)"
)


def _meaningful_ngrams(text):
    """去除通用问句成分后提取2-gram，提高话题区分度。"""
    cleaned = _GENERIC_QUESTION_PATTERNS.sub("", text)
    return _char_ngrams(cleaned)


def _is_topic_continuation(question, last_question):
    """
    检测当前问题与上一轮问题是否话题连续（基于有效2-gram重叠）。

    判定规则：
    - 有效2-gram交集 >= 2 → 话题连续
    - 交集 = 1 但占较短问题的20%以上 → 也算连续（应对短追问如'75mm的'）
    - 否则 → 话题已切换

    '有效'指去除了'是多少''多少钱'等通用问句成分后的2-gram，
    避免'出库价是多少'和'批发均价是多少'因共享问句被误判为同话题。
    """
    if not last_question:
        return False
    g1 = _meaningful_ngrams(last_question)
    g2 = _meaningful_ngrams(question)
    if not g1 or not g2:
        return False
    overlap = g1 & g2
    if len(overlap) >= 2:
        return True
    if len(overlap) >= 1 and len(overlap) / min(len(g1), len(g2)) >= 0.2:
        return True
    return False


def _filter_history_for_question(question, history):
    """
    根据当前问题筛选传给模型的历史轮次（防止话题切换时旧内容干扰）。

    策略：
    - 无历史 → 空列表
    - 含指代词（'刚才''那个'等）→ 至少保留最近一轮
    - 从最近轮次往前追溯，保留与当前话题连续的轮次，遇到切换点停止
    - 页面始终显示完整历史，此函数只控制传给模型的部分

    这样做的原因：模型会把传入的历史当作上下文，如果上一轮聊苹果气调、
    这一轮问猕猴桃催熟，旧历史会让模型把两个话题混在一起回答。
    """
    if not history:
        return []

    has_ref = _has_reference_word(question)

    # 按轮次分组（user + assistant 两条消息 = 1轮）
    turns = []
    i = 0
    while i < len(history):
        turns.append(history[i:i + 2])
        i += 2

    # 从最近轮次往前追溯
    selected = []
    for turn in reversed(turns):
        turn_question = ""
        for msg in turn:
            if msg.get("role") == "user":
                turn_question = msg.get("content", "")
                break
        if not turn_question:
            continue

        is_related = _is_topic_continuation(question, turn_question)

        if is_related:
            selected.insert(0, turn)
        elif has_ref and not selected:
            # 指代词场景：至少保留最近一轮，让模型能理解指代对象
            selected.insert(0, turn)
        else:
            # 话题切换且非指代 → 停止往前追溯
            break

    # 展平成消息列表
    result = []
    for turn in selected:
        result.extend(turn)
    return result


@app.route("/consult", methods=["GET", "POST"])
def consult():
    """
    咨询页（多轮对话 + 资料检索版）：
    - GET ：显示提问页面，带历史对话记录
    - POST：接收问题 → 检索导入的文档资料 → 拼接会话历史 → 调用大模型
            → 保存历史 → 显示回答和实际使用的来源

    会话隔离：使用 Flask session（cookie），每个浏览器独立，
    不同用户的对话历史互不可见。
    来源展示：页面显示的参考资料来自程序检索结果，不是模型生成的，
    因此不会出现模型编造的链接。
    """
    question = None
    results = None
    llm_answer = None
    llm_error = False
    searched = False
    sources = []  # 本轮检索到的参考资料（展示给用户，来自检索而非模型）
    sources_has_cited = False  # 是否有程序核验的"正文实际引用"

    # 从会话中加载对话历史（每个浏览器独立，天然隔离）
    history = session.get("chat_history", [])

    if request.method == "POST":
        # 支持清空对话操作
        if request.form.get("action") == "clear":
            session.pop("chat_history", None)
            history = []
            return render_template(
                "consult.html",
                active_page="consult",
                question=None,
                results=None,
                searched=False,
                llm_configured=LLM_CONFIGURED,
                llm_answer=None,
                llm_error=False,
                llm_model_name=config.LLM_MODEL_NAME,
                chat_history=[],
                sources=[],
                sources_has_cited=False,
                docs_empty=(len(DOC_CHUNKS) == 0),
            )

        question = request.form.get("question", "").strip()
        if question:
            searched = True

            # ---- 第0步：筛选传给模型的历史（话题切换裁剪，追问保留）----
            filtered_history = _filter_history_for_question(question, history)

            # ---- 第1步：检索导入的文档资料（RAG）----
            doc_hits = search_docs(question)
            # 追问场景下当前问题可能太短（如"那75mm的呢"）导致检索为空，
            # 此时用上一轮问题补充检索，保证模型有相关资料可参考
            if not doc_hits and filtered_history:
                last_q = ""
                for msg in reversed(filtered_history):
                    if msg.get("role") == "user":
                        last_q = msg.get("content", "")
                        break
                if last_q:
                    doc_hits = search_docs(last_q)
            context = None
            if doc_hits:
                context_parts = []
                for i, chunk in enumerate(doc_hits, 1):
                    context_parts.append(
                        "[%d] 《%s》— %s\n来源：%s（%s）\n%s"
                        % (i, chunk["title"], chunk["section"],
                           chunk["publisher"] or "未标注机构", chunk["date"],
                           chunk["text"])
                    )
                context = "\n\n".join(context_parts)

            # ---- 第2步：调用大模型，传入筛选后的历史和检索到的资料 ----
            llm_answer = ask_llm(question, filtered_history, context)
            if llm_answer is None:
                llm_error = True
            else:
                # 模型回答成功，将本轮问答追加到会话历史
                history.append({"role": "user", "content": question})
                history.append({"role": "assistant", "content": llm_answer})
                # 限制历史长度，只保留最近 MAX_HISTORY_TURNS 轮
                if len(history) > MAX_HISTORY_TURNS * 2:
                    history = history[-(MAX_HISTORY_TURNS * 2):]
                session["chat_history"] = history

            # ---- 第3步：按 source_id 去重折叠构建来源列表 ----
            # 程序核验：从回答中提取 [编号]，对应检索候选中的编号，
            # 出现过的标为"正文实际引用"，未出现的标为"检索候选"。
            # 不能仅凭模型声明认定，以程序可见的编号为准。
            if doc_hits:
                cited_indices = set()
                if llm_answer:
                    for m in re.finditer(r"\[(\d+)\]", llm_answer):
                        cited_indices.add(int(m.group(1)))
                source_map = {}  # source_id -> 折叠后的来源条目
                for i, chunk in enumerate(doc_hits, 1):
                    sid = chunk["source_id"]
                    if sid not in source_map:
                        source_map[sid] = {
                            "source_id": sid,
                            "title": chunk["title"],
                            "publisher": chunk.get("publisher", ""),
                            "date": chunk.get("date", ""),
                            "product": chunk.get("product", ""),
                            "source_url": chunk.get("source_url", ""),
                            "sections": [],
                            "indices": [],
                        }
                    entry = source_map[sid]
                    if chunk["section"] not in entry["sections"]:
                        entry["sections"].append(chunk["section"])
                    entry["indices"].append(i)
                sources = list(source_map.values())
                has_cited = False
                for s in sources:
                    s["cited"] = any(idx in cited_indices for idx in s["indices"])
                    s["section_count"] = len(s["sections"])
                    if s["cited"]:
                        has_cited = True
                # 实际引用排前面，检索候选排后面
                sources.sort(key=lambda x: (not x["cited"]))
                # 有程序核验的实际引用时才区分，否则统一标检索候选
                sources_has_cited = has_cited

            # 同时检索知识库，作为补充资料
            results = search_knowledge(question)

    return render_template(
        "consult.html",
        active_page="consult",
        question=question,
        results=results,
        searched=searched,
        llm_configured=LLM_CONFIGURED,
        llm_answer=llm_answer,
        llm_error=llm_error,
        llm_model_name=config.LLM_MODEL_NAME,
        chat_history=history,
        sources=sources,
        sources_has_cited=sources_has_cited,
        docs_empty=(len(DOC_CHUNKS) == 0),
    )


# ============================================================
# 阶段3：公开行情解读
# ============================================================

@app.route("/market")
def market():
    """
    行情页：展示公开渠道整理的苹果/猕猴桃行情数据。
    数据来源：data/market.json + data/market_csv/ 下导入的 CSV 行情表。
    每条数据都标注来源和日期，页面底部有免责声明。
    """
    apple_market, kiwi_market, industry_facts, update_date = load_market()
    # 合并 CSV 导入的行情（按产品类型分到对应列表）
    apple_market = apple_market + [r for r in CSV_MARKET_ROWS if r["_type"] == "apple"]
    kiwi_market = kiwi_market + [r for r in CSV_MARKET_ROWS if r["_type"] == "kiwi"]
    return render_template(
        "market.html",
        active_page="market",
        apple_market=apple_market,
        kiwi_market=kiwi_market,
        industry_facts=industry_facts,
        update_date=update_date,
    )


# ============================================================
# 阶段4：报价可比性检查
# ============================================================

def parse_price_per_jin(price_str):
    """
    从行情价格字符串中提取"元/斤"的数值。

    能识别的格式：
    - "3.3~3.8 元/斤"        → (3.3, 3.8) 范围
    - "3.5 元/斤"            → (3.5, 3.5) 单值
    - "10.0 元/公斤（合 5.0 元/斤）" → (5.0, 5.0) 取换算后的斤价
    - "约 3 元多/斤"          → (3.0, 3.9) 约数

    返回 (最低价, 最高价) 元组；无法解析时返回 None。
    """
    # 优先匹配 "合 X.X 元/斤"（公斤换算标注）
    m = re.search(r"合\s*([\d.]+)\s*元/斤", price_str)
    if m:
        v = float(m.group(1))
        return (v, v)
    # 匹配范围 "X.X~X.X 元/斤"
    m = re.search(r"([\d.]+)\s*[~～]\s*([\d.]+)\s*元/斤", price_str)
    if m:
        return (float(m.group(1)), float(m.group(2)))
    # 匹配单值 "X.X 元/斤"
    m = re.search(r"([\d.]+)\s*元/斤", price_str)
    if m:
        v = float(m.group(1))
        return (v, v)
    # 匹配 "约 X 元多/斤"
    m = re.search(r"约\s*([\d.]+)\s*元多?/斤", price_str)
    if m:
        v = float(m.group(1))
        return (v, v + 0.9)
    return None


def get_spec_grade(spec_text):
    """从规格文本中提取等级关键词（统货 / 半商品 / 批发 / 其他）"""
    if "半商品" in spec_text:
        return "半商品"
    if "统货" in spec_text:
        return "统货"
    if "批发" in spec_text:
        return "批发"
    return "其他"


def check_quote(form):
    """
    核心比对逻辑：将用户报价与 market.json 参考行情逐项比对。

    比对步骤：
    1. 按品种（苹果/猕猴桃）筛选参考行情
    2. 按价格环节（产地收购价/批发市场价）筛选，跨环节不可比
    3. 按产地匹配度分级：县级精确匹配 > 同省 > 外省对照
    4. 检查规格等级是否一致（统货 vs 半商品 不能直接对比）
    5. 价格分析：用户单价 vs 参考区间，计算偏差

    返回结果字典，包含结论、原因、参考条目、价格分析。
    """
    product_type = form.get("product_type", "")
    product_name = form.get("product_name", "").strip()
    origin = form.get("origin", "").strip()
    spec = form.get("spec", "").strip()
    quantity = form.get("quantity", "").strip()
    price_str = form.get("price", "").strip()
    price_stage = form.get("price_stage", "")
    quote_date = form.get("quote_date", "").strip()

    # 用户报价回显（传给结果页显示）
    user_quote = {
        "product_type": product_type,
        "product_type_label": "🍎 苹果" if product_type == "apple" else "🥝 猕猴桃",
        "product_name": product_name,
        "origin": origin,
        "spec": spec,
        "quantity": quantity,
        "price": price_str,
        "price_stage": price_stage,
        "quote_date": quote_date,
    }

    # 加载参考行情
    apple_market, kiwi_market, _, update_date = load_market()
    ref_all = apple_market if product_type == "apple" else kiwi_market

    reasons = []
    warnings = []

    # ---- 第1步：按价格环节筛选 ----
    same_stage = []
    for r in ref_all:
        cat = r.get("category", "")
        if price_stage in cat:
            same_stage.append(r)

    if not same_stage:
        # 没有同环节参考数据 → 不可比
        return {
            "conclusion": "不可比",
            "conclusion_class": "bad",
            "user_quote": user_quote,
            "reasons": [
                "参考行情中没有「%s」环节的%s数据，无法直接比对。" % (price_stage, user_quote["product_type_label"]),
                "提示：产地收购价、批发市场价、零售价是不同环节的价格，不能跨环节直接对比。",
            ],
            "warnings": warnings,
            "matched_refs": [],
            "price_analysis": None,
            "update_date": update_date,
        }

    # ---- 第2步：按产地匹配度分级 ----
    exact_origin = []    # 县级产地匹配（如"洛川"出现在用户产地中）
    same_province = []   # 同属陕西
    diff_province = []   # 外省对照

    for r in same_stage:
        ref_origin = r.get("origin", "")
        # 提取参考条目的县级地名（·分隔的最后一段）
        ref_county = ref_origin.split("·")[-1] if "·" in ref_origin else ref_origin
        if ref_county and ref_county in origin:
            exact_origin.append(r)
        elif "陕西" in ref_origin and "陕西" in origin:
            same_province.append(r)
        else:
            diff_province.append(r)

    # ---- 第3步：确定最佳参考条目 ----
    if exact_origin:
        best_refs = exact_origin
        match_level = "exact"
    elif same_province:
        best_refs = same_province
        match_level = "province"
    else:
        best_refs = diff_province
        match_level = "out"

    # ---- 第4步：规格等级检查 ----
    user_grade = get_spec_grade(spec)
    spec_mismatch = False
    for r in best_refs:
        ref_grade = get_spec_grade(r.get("spec", ""))
        if user_grade != "其他" and ref_grade != "其他" and user_grade != ref_grade:
            spec_mismatch = True
            warnings.append(
                "你填的规格是「%s」（%s），参考条目规格是「%s」（%s），"
                "等级不同，价格差异可能主要来自等级而非行情波动。" % (spec, user_grade, r["spec"], ref_grade)
            )
            break

    # ---- 第5步：判定结论 ----
    if match_level == "exact" and not spec_mismatch:
        conclusion = "可比"
        conclusion_class = "good"
        reasons.append("找到了你所在产地（%s）同环节、同等级的参考行情，可以直接比对价格。" % origin)
    elif match_level == "exact" and spec_mismatch:
        conclusion = "部分可比"
        conclusion_class = "mid"
        reasons.append("找到了你所在产地（%s）同环节的参考行情，但规格等级不同，只能作参考。" % origin)
    elif match_level == "province":
        conclusion = "部分可比"
        conclusion_class = "mid"
        reasons.append("没有找到你所在县区的参考行情，但找到了同属陕西的其他产区数据，产区相近可作参考。")
    else:
        conclusion = "部分可比"
        conclusion_class = "mid"
        reasons.append("没有找到陕西产区的同环节参考数据，仅有外省对照数据，产地差异较大，仅供参考。")

    # ---- 第6步：价格分析 ----
    price_analysis = None
    try:
        user_price = float(price_str)
    except (ValueError, TypeError):
        user_price = None

    if user_price is not None and user_price >= 0:
        # 解析所有最佳参考条目的价格区间
        ref_prices = []
        for r in best_refs:
            parsed = parse_price_per_jin(r.get("price", ""))
            if parsed:
                ref_prices.append(parsed)

        if ref_prices:
            ref_min = min(p[0] for p in ref_prices)
            ref_max = max(p[1] for p in ref_prices)

            # 判断用户价格位置
            if user_price < ref_min:
                deviation = (user_price - ref_min) / ref_min * 100
                position = "低于参考区间下限"
            elif user_price > ref_max:
                deviation = (user_price - ref_max) / ref_max * 100
                position = "高于参考区间上限"
            else:
                deviation = 0
                position = "在参考区间内"

            # 计算价格标尺位置（0 ~ bar_max 映射到 0% ~ 100%）
            bar_max = max(ref_max, user_price) * 1.15
            if bar_max <= 0:
                bar_max = 1.0

            def to_pct(v):
                return max(0, min(100, round(v / bar_max * 100, 1)))

            price_analysis = {
                "user_price": user_price,
                "ref_min": ref_min,
                "ref_max": ref_max,
                "deviation": round(abs(deviation), 1),
                "position": position,
                "bar_user_pos": to_pct(user_price),
                "bar_range_left": to_pct(ref_min),
                "bar_range_width": max(2, to_pct(ref_max) - to_pct(ref_min)),
                "bar_max": round(bar_max, 1),
            }

            # 根据偏差大小给出解读
            if position == "在参考区间内":
                reasons.append("你报的单价 %s 元/斤，在参考行情区间（%s~%s 元/斤）内，属于正常范围。"
                               % (user_price, ref_min, ref_max))
            elif deviation >= 20:
                reasons.append("你报的单价 %s 元/斤，比参考行情区间（%s~%s 元/斤）%s %.1f%%，"
                               "偏差较大，建议核实规格等级和价格环节是否一致。"
                               % (user_price, ref_min, ref_max, position, deviation))
            else:
                reasons.append("你报的单价 %s 元/斤，%s（参考区间 %s~%s 元/斤），偏差 %.1f%%，在合理波动范围内。"
                               % (user_price, position, ref_min, ref_max, deviation))

    # ---- 第7步：时间差异提醒 ----
    if quote_date:
        reasons.append("注意：你的报价时间是 %s，参考行情数据整理日期为 %s，行情会随时间变化，请关注时效性。"
                       % (quote_date, update_date))

    return {
        "conclusion": conclusion,
        "conclusion_class": conclusion_class,
        "user_quote": user_quote,
        "reasons": reasons,
        "warnings": warnings,
        "matched_refs": best_refs,
        "price_analysis": price_analysis,
        "update_date": update_date,
    }


@app.route("/quote", methods=["GET", "POST"])
def quote():
    """
    报价检查页：
    - GET ：显示空的报价表单
    - POST：校验表单 → 比对 → 显示结果页
    """
    if request.method == "GET":
        return render_template("quote.html", active_page="quote", form=None, errors=None)

    # ---- POST：校验必填字段 ----
    required_fields = [
        ("product_type", "品种类型"),
        ("origin", "产地"),
        ("spec", "规格"),
        ("price", "单价"),
        ("price_stage", "价格环节"),
    ]
    errors = []
    for field, label in required_fields:
        if not request.form.get(field, "").strip():
            errors.append("「%s」为必填项，请填写后重试。" % label)

    # 校验单价必须是数字
    price_val = request.form.get("price", "").strip()
    if price_val and not errors:
        try:
            v = float(price_val)
            if v < 0:
                errors.append("「单价」不能是负数。")
        except ValueError:
            errors.append("「单价」必须是数字（例如：3.5），当前输入的是「%s」。" % price_val)

    # 有错误 → 回到表单页，保留用户已填内容并显示错误
    if errors:
        return render_template("quote.html", active_page="quote", form=request.form, errors=errors)

    # 校验通过 → 执行比对，渲染结果页
    result = check_quote(request.form)
    return render_template("result.html", active_page="quote", result=result)


# ============================================================
# 两条报价口径检查
# ============================================================

def convert_to_jin(price, unit, box_weight):
    """
    将报价换算到元/斤。

    - jin（元/斤）  ：直接返回
    - kg（元/公斤）  ：÷ 2
    - box（元/箱）   ：÷ 箱重（斤/箱）；缺少箱重返回 None

    返回 (元/斤数值, 错误信息)；无法换算时返回 (None, 错误信息)。
    """
    try:
        p = float(price)
    except (ValueError, TypeError):
        return None, "单价不是有效数字"

    if unit == "jin":
        return p, None
    if unit == "kg":
        return round(p / 2, 2), None
    if unit == "box":
        if not box_weight or float(box_weight) <= 0:
            return None, "单位为元/箱但未填写每箱重量，无法换算"
        return round(p / float(box_weight), 2), None
    return None, "未知单位"


def check_compare(form):
    """
    两条报价口径检查：
    1. 逐项对比品种/产地/规格/环节是否一致
    2. 统一换算到元/斤（元/箱缺少箱重则标记无法换算）
    3. 如果都能换算，计算价差和百分比
    """
    # ---- 提取两条报价 ----
    def extract(prefix):
        product_type = form.get(prefix + "_product_type", "")
        unit = form.get(prefix + "_price_unit", "")
        unit_labels = {"jin": "元/斤", "kg": "元/公斤", "box": "元/箱"}
        return {
            "product_type": product_type,
            "product_type_label": "🍎 苹果" if product_type == "apple" else "🥝 猕猴桃",
            "origin": form.get(prefix + "_origin", "").strip(),
            "spec": form.get(prefix + "_spec", "").strip(),
            "price_stage": form.get(prefix + "_price_stage", ""),
            "price": form.get(prefix + "_price", "").strip(),
            "price_unit": unit,
            "unit_label": unit_labels.get(unit, unit),
            "box_weight": form.get(prefix + "_box_weight", "").strip(),
        }

    q1 = extract("q1")
    q2 = extract("q2")

    # ---- 逐项口径对比 ----
    checks = {
        "type": q1["product_type"] == q2["product_type"],
        "origin": q1["origin"] == q2["origin"],
        "spec": q1["spec"] == q2["spec"],
        "stage": q1["price_stage"] == q2["price_stage"],
    }
    all_aligned = all(checks.values())

    # ---- 单位换算 ----
    q1_jin, q1_err = convert_to_jin(q1["price"], q1["price_unit"], q1["box_weight"])
    q2_jin, q2_err = convert_to_jin(q2["price"], q2["price_unit"], q2["box_weight"])
    q1["jin_price"] = q1_jin
    q2["jin_price"] = q2_jin

    # ---- 价格对比（两条都能换算时才计算） ----
    price_diff = None
    if q1_jin is not None and q2_jin is not None:
        diff = round(q1_jin - q2_jin, 2)
        if diff > 0:
            direction = "高"
        elif diff < 0:
            direction = "低"
        else:
            direction = "相同"
        # 百分比以报价B为基准
        if q2_jin != 0:
            percent = round(abs(diff) / q2_jin * 100, 1)
        else:
            percent = 0
        price_diff = {
            "diff": abs(diff),
            "direction": direction,
            "percent": percent,
        }

    return {
        "q1": q1,
        "q2": q2,
        "checks": checks,
        "all_aligned": all_aligned,
        "price_diff": price_diff,
    }


@app.route("/compare", methods=["GET", "POST"])
def compare():
    """
    两条报价口径检查页：
    - GET ：显示空表单
    - POST：校验 → 口径检查 → 同页显示结果
    """
    if request.method == "GET":
        return render_template("compare.html", active_page="compare", form=None, errors=None, result=None)

    # ---- POST：校验必填字段 ----
    errors = []
    for prefix, label in [("q1", "报价A"), ("q2", "报价B")]:
        for field, name in [("product_type", "品种类型"), ("origin", "产地"),
                            ("spec", "规格"), ("price", "单价"), ("price_stage", "价格环节")]:
            if not request.form.get(prefix + "_" + field, "").strip():
                errors.append("%s的「%s」为必填项。" % (label, name))

        # 单价为元/箱时，箱重必填
        unit = request.form.get(prefix + "_price_unit", "")
        box_w = request.form.get(prefix + "_box_weight", "").strip()
        if unit == "box" and (not box_w or float(box_w) <= 0):
            errors.append("%s的单位是元/箱，必须填写每箱重量（斤）才能换算。" % label)

    if errors:
        return render_template("compare.html", active_page="compare", form=request.form, errors=errors, result=None)

    # 校验通过 → 执行检查
    result = check_compare(request.form)
    return render_template("compare.html", active_page="compare", form=request.form, errors=None, result=result)


# ============================================================
# 资料管理：重新加载外部资料
# ============================================================

@app.route("/reload", methods=["POST"])
def reload_data():
    """
    重新加载 data/docs/ 和 data/market_csv/ 下的外部资料。

    使用场景：用户放入或替换了资料文件后，点击知识库页的
    「重新加载资料」按钮触发。重复加载不会产生重复记录
    （每次先清空缓存再装填，CSV 按整行指纹去重，文档按 source_id 去重）。
    """
    stats = reload_all_data()
    flash("资料已重新加载：文档 %d 篇（%d 个检索块），行情 CSV %d 条"
          % (stats["docs"], stats["chunks"], stats["csv_rows"]))
    return redirect(url_for("knowledge"))


# 程序启动时自动加载外部资料（data/docs/ 和 data/market_csv/）
# debug 模式下 reloader 会执行两次，但加载是幂等的（先清空再装填），无副作用
reload_all_data()


# 程序入口：当你运行 `python app.py` 时，从这里开始执行
if __name__ == "__main__":
    # host="0.0.0.0"：允许局域网/外网访问（云部署的硬性要求）
    # port=8080：JoyCode 云平台只开放 8080 端口，本地也保持一致
    # debug=True：开发模式，改代码后自动重启，方便调试；部署时会关掉
    app.run(host="0.0.0.0", port=8080, debug=True)