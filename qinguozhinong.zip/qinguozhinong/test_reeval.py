# -*- coding: utf-8 -*-
"""快速复验 V2_03 / V2_04：同义词扩展后检索是否命中正确文档"""
import re
import time
import requests

BASE = 'http://127.0.0.1:8080/consult'


def ask(s, q):
    t0 = time.time()
    r = s.post(BASE, data={'question': q}, timeout=90)
    dt = round(time.time() - t0, 1)
    t = r.text
    bubbles = re.findall(r'bubble-assistant[^>]*>(.*?)</div>\s*</div>', t, re.S)
    ans = re.sub(r'<[^>]+>', ' ', bubbles[-1]).strip() if bubbles else ''
    ans = re.sub(r'\s+', ' ', ans)
    sids = re.findall(r'rag-sid">(QG_[A-Z0-9]+)</span>', t)
    return ans, sids, dt


# V2_03：苹果长了霉，切掉一块剩下可以吃吗？
s1 = requests.Session()
a1, src1, d1 = ask(s1, '苹果长了霉，切掉一块剩下可以吃吗？')
ok1 = 'QG_A003' in src1 and ('不建议' in a1 or '丢弃' in a1 or '不要' in a1)
print(f"V2_03 [{'通过' if ok1 else '未通过'}] {d1}s 来源:{src1}")
print(f"  答: {a1[:150]}")
print()

# V2_04：整箱苹果想多放几天，要和硬猕猴桃一起装吗？
s2 = requests.Session()
a2, src2, d2 = ask(s2, '整箱苹果想多放几天，要和硬猕猴桃一起装吗？')
ok2 = 'QG_A002' in src2 and ('乙烯' in a2 or '分开' in a2 or '催熟' in a2)
print(f"V2_04 [{'通过' if ok2 else '未通过'}] {d2}s 来源:{src2}")
print(f"  答: {a2[:150]}")