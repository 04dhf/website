# -*- coding: utf-8 -*-
"""资料包导入验证：字段映射/数量/日期/去重/链接/演示文件停用。"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import app

PASS = 0
FAIL = 0

def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  ✅ %s" % name)
    else:
        FAIL += 1
        print("  ❌ %s %s" % (name, detail))

print("=" * 60)
print("测试1：重新加载 — 预期8篇文档、4条行情")
print("=" * 60)
stats = app.reload_all_data()
check("文档数 = 8", stats["docs"] == 8, "实际 %d" % stats["docs"])
check("CSV行情 = 4", stats["csv_rows"] == 4, "实际 %d" % stats["csv_rows"])
check("演示文件已停用（不在导入列表）",
      all(d["source_id"] != "SRC-2026-001" for d in app.DOCS_META))

print()
print("=" * 60)
print("测试2：字段映射 url→source_url, publish_date→date, scenario→scene")
print("=" * 60)
by_id = {d["source_id"]: d for d in app.DOCS_META}
a001 = by_id.get("QG_A001", {})
check("QG_A001 存在", "QG_A001" in by_id)
check("source_url 映射成功（农业农村部链接）",
      a001.get("source_url", "").startswith("https://scs.moa.gov.cn"),
      a001.get("source_url", ""))
check("date 映射成功（2023-02-03）",
      a001.get("date") == "2023-02-03", a001.get("date"))
check("scene 映射成功（含'商业贮藏'）",
      "商业贮藏" in a001.get("scene", ""), a001.get("scene", ""))
check("product 保留分号文本",
      "苹果" in a001.get("product", ""), a001.get("product", ""))
check("7个字段全部保留",
      all(k in a001 for k in ("source_id", "title", "publisher",
                               "source_url", "date", "product", "scene")))

r001 = by_id.get("QG_R001", {})
check("QG_R001 publisher 标为项目整理非政府标准",
      "项目" in r001.get("publisher", "") and "非政府" in r001.get("publisher", ""),
      r001.get("publisher", ""))

print()
print("=" * 60)
print("测试3：CSV 4条同source_id不同规格行情全部保留")
print("=" * 60)
rows = app.CSV_MARKET_ROWS
check("4条行情全部保留", len(rows) == 4, "实际 %d" % len(rows))
grades = sorted(r["spec"] for r in rows)
check("4种规格 75/80/85/90mm",
      grades == ["75mm", "80mm", "85mm", "90mm"], str(grades))
prices = {r["spec"]: r["price"] for r in rows}
check("75mm = 4.14 元/斤", prices.get("75mm") == "4.14 元/斤", str(prices.get("75mm")))
check("80mm = 4.89 元/斤", prices.get("80mm") == "4.89 元/斤", str(prices.get("80mm")))
check("85mm = 5.32 元/斤", prices.get("85mm") == "5.32 元/斤", str(prices.get("85mm")))
check("90mm = 5.51 元/斤", prices.get("90mm") == "5.51 元/斤", str(prices.get("90mm")))
check("全部 source_id = QG_M001",
      all(r["source"].find("QG_M001") >= 0 for r in rows))
check("全部归类为苹果", all(r["_type"] == "apple" for r in rows))

print()
print("=" * 60)
print("测试4：日期 2026-01 保持月报时期，不捏造具体日期")
print("=" * 60)
dates = set(r["date"] for r in rows)
check("日期为 2026-01（非 2026-01-01）", dates == {"2026-01"}, str(dates))
check("stage 含月报口径",
      all("月报" in r["category"] for r in rows))

print()
print("=" * 60)
print("测试5：重复加载不增加记录")
print("=" * 60)
app.reload_all_data()
app.reload_all_data()
check("3次加载后文档仍 8 篇", len(app.DOCS_META) == 8, "实际 %d" % len(app.DOCS_META))
check("3次加载后行情仍 4 条", len(app.CSV_MARKET_ROWS) == 4,
      "实际 %d" % len(app.CSV_MARKET_ROWS))

print()
print("=" * 60)
print("测试6：来源链接完整保留（8篇文档各有一条URL）")
print("=" * 60)
for d in app.DOCS_META:
    url = d.get("source_url", "")
    ok = url.startswith("https://")
    check("%s 链接有效: %s..." % (d["source_id"], url[:40]), ok, url)

print()
print("=" * 60)
print("测试7：检索命中资料包内容")
print("=" * 60)
hits = app.search_docs("富士商业气调氧气二氧化碳浓度")
check("气调问题命中 QG_A001", any(h["source_id"] == "QG_A001" for h in hits),
      str([h["source_id"] for h in hits]))
if hits:
    a001_hit = [h for h in hits if h["source_id"] == "QG_A001"]
    if a001_hit:
        text = a001_hit[0]["text"]
        check("命中正确参数 3%—5%、0%—2%",
              "3%" in text and "5%" in text and "0%" in text and "2%" in text)

hits2 = app.search_docs("猕猴桃出库价格区间")
check("出库价问题命中月报文档",
      any(h["source_id"] in ("QG_M001", "QG_M002", "QG_M003") for h in hits2),
      str([h["source_id"] for h in hits2]))

hits3 = app.search_docs("报价比较规则")
check("规则问题命中 QG_R001", any(h["source_id"] == "QG_R001" for h in hits3),
      str([h["source_id"] for h in hits3]))

print()
print("=" * 60)
print("结果：%d 通过，%d 失败" % (PASS, FAIL))
print("=" * 60)
sys.exit(1 if FAIL else 0)