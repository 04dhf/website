# -*- coding: utf-8 -*-
"""复测：串题案例（气调→猕猴桃）+ 指代案例（80mm→75mm追问）"""
import re
import time
import requests

BASE = 'http://127.0.0.1:8080/consult'


def ask(s, q):
    """提问并返回（纯文本回答, 来源ID列表, 耗时秒）
    注意：页面 chat_history 包含所有轮次，必须取最后一个 bubble-assistant。
    """
    t0 = time.time()
    r = s.post(BASE, data={'question': q}, timeout=60)
    dt = round(time.time() - t0, 1)
    t = r.text
    bubbles = re.findall(r'bubble-assistant[^>]*>(.*?)</div>\s*</div>', t, re.S)
    ans = re.sub(r'<[^>]+>', ' ', bubbles[-1]).strip() if bubbles else ''
    sids = re.findall(r'rag-sid">(QG_[A-Z0-9]+)</span>', t)
    return ans, sids, dt


def clean(s):
    """压缩空白便于判断"""
    return re.sub(r'\s+', '', s)


print('=' * 60)
print('案例1：串题测试（气调 → 猕猴桃，检查零污染）')
print('=' * 60)
s1 = requests.Session()
a1, src1, d1 = ask(s1, '苹果商业贮藏气调参数是什么')
print(f'[轮1] 气调问题 | {d1}s | 来源{src1}')
print(f'  回答前120字: {a1[:120]}')

a2, src2, d2 = ask(s1, '翠香猕猴桃有什么特点')
print(f'[轮2] 猕猴桃问题 | {d2}s | 来源{src2}')
print(f'  回答前200字: {a2[:200]}')

# 判定：猕猴桃回答不应包含气调参数污染
pollution_words = ['氧气3%', '二氧化碳0%', '气调库', '气调参数', '富士系氧气']
polluted = [w for w in pollution_words if w in clean(a2)]
if polluted:
    print(f'  ❌ 串题污染！出现: {polluted}')
else:
    print('  ✅ 无串题污染，猕猴桃回答干净')

print()
print('=' * 60)
print('案例2：指代测试（80mm苹果价 → "那75mm的呢"）')
print('=' * 60)
s2 = requests.Session()
a3, src3, d3 = ask(s2, '80mm红富士苹果什么价')
print(f'[轮1] 80mm问价 | {d3}s | 来源{src3}')
print(f'  回答前200字: {a3[:200]}')

a4, src4, d4 = ask(s2, '那75mm的呢')
print(f'[轮2] 75mm追问 | {d4}s | 来源{src4}')
print(f'  回答前200字: {a4[:200]}')

# 判定：追问回答应包含75mm相关信息
a4c = clean(a4)
if '75' in a4c:
    print('  ✅ 追问成功承接，回答包含75mm信息')
else:
    print('  ❌ 追问未承接75mm')