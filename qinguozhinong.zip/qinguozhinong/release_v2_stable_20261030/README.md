# 秦果知农 — 网页智能体

面向果农和消费者的陕西苹果 / 猕猴桃知识咨询与行情解读工具。
基于 Flask + 大模型 RAG 检索增强，所有回答附带可溯源的参考资料。

## 功能页面

| 页面 | 网址 | 说明 |
|---|---|---|
| 首页 | `/` | 项目介绍 + 功能入口 |
| 知识库 | `/knowledge` | 浏览全部科普文档与行情数据 |
| 智能咨询 | `/consult` | 多轮对话问答，展示检索来源 |
| 行情解读 | `/market` | 公开渠道行情展示与解读 |
| 报价检查 | `/quote` | 报价可比性检查（规格/产地/时间） |

## 本地启动

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

依赖清单：flask 3.0.3、gunicorn 23.0.0、requests 2.32.3（Python 3.12）。

### 2. 配置大模型密钥

打开 `config.py`，将 `LLM_API_KEY` 替换为你自己的密钥（智谱 OpenAI 兼容接口）。
不配置密钥时咨询页自动回退到本地关键词检索模式，其他页面不受影响。

### 3. 启动

```bash
python app.py
```

浏览器访问 http://127.0.0.1:8080

### 4. 导入资料（可选）

- 将 Markdown 文档放入 `data/docs/`（文件头部需含 source_id 等 7 字段）
- 将 CSV 行情放入 `data/market_csv/`（9 字段：source_id/product/variety/grade/region/stage/date/price/unit）
- 到知识库页点击「重新加载资料」，或调用 `/reload` 接口
- 重复加载自动去重，不会产生重复记录

## Docker 部署

```bash
docker build -t qinguozhinong .
docker run -p 8080:8080 qinguozhinong
```

镜像基于 python:3.12-slim，使用 gunicorn 生产级服务器，监听 0.0.0.0:8080。

## 数据说明

- **科普文档**：15 篇（data/docs/），来自农业农村部、新华网、宝鸡果业中心等公开渠道
- **行情 CSV**：10 条（data/market_csv/），覆盖 2025-10 猕猴桃与 2026-01 苹果
- 所有数据标注来源与日期，不编造任何数据

## 项目结构

```
├── app.py              # 主程序（Flask 路由 + RAG 检索 + 大模型调用）
├── config.py           # 大模型接口配置（密钥需自行填入）
├── requirements.txt    # Python 依赖
├── Dockerfile          # Docker 部署配置
├── templates/          # Jinja2 页面模板
├── data/
│   ├── docs/           # Markdown 科普文档（15 篇）
│   ├── market_csv/     # CSV 行情数据（10 条）
│   ├── knowledge.json  # 基础知识库
│   └── market.json     # 行情解读数据
└── static/             # 静态资源
```