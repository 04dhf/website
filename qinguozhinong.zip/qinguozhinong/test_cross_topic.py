# -*- coding: utf-8 -*-
"""复现串题案例 + 验证正常追问（通过HTTP调用真实/consult接口）。"""
import os
import re
import sys
import requests

BASE = "http://127.0.0.1:8080"

passed = 0
failed = 0


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print("  [PASS] %s" % name)
    else:
        failed += 1
        print("  [FAIL] %s %s" % (name, detail))


def ask(sess, question):
    """向/consult发送问题，返回(回答文本, 来源列表HTML)。"""
    r = sess.post(BASE + "/consult", data={"question": question})
    if r.status_code != 200:
        return None, r.status_code
    html = r.text
    # 回答在 chat-bubble bubble-assistant 中，取最后一条（本轮回答）
    bubbles = re.findall(
        r'class="chat-bubble bubble-assistant"[^>]*>(.*?)</div>', html, re.S)
    answer = bubbles[-1].strip() if bubbles else ""
    # 去HTML标签和实体
    answer = re.sub(r"<[^>]+>", "", answer)
    answer = answer.replace("&#39;", "'").replace("&quot;", '"')
    answer = answer.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    answer = answer.strip()
    # 提取来源ID
    sources = re.findall(r"QG_[A-Z]\d+", html)
    return answer, sorted(set(sources))


print("=" * 60)
print("测试A：串题案例复现（苹果气调 → 猕猴桃催熟）")
print("=" * 60)
sessA = requests.Session()

q1 = "富士商业气调氧气2%—4%、二氧化碳1%—3%对吗？"
ans1, src1 = ask(sessA, q1)
print("第1轮问题: %s" % q1)
print("第1轮回答(前200字): %s" % (ans1[:200] if ans1 else "无回答"))
print("第1轮来源: %s" % src1)
check("第1轮有回答", ans1 is not None and len(ans1) > 10)
check("第1轮来源含QG_A001", "QG_A001" in src1, "来源=%s" % src1)

q2 = "所有陕西猕猴桃都能按上海案例3天变甜吗？"
ans2, src2 = ask(sessA, q2)
print()
print("第2轮问题: %s" % q2)
print("第2轮回答(前300字): %s" % (ans2[:300] if ans2 else "无回答"))
print("第2轮来源: %s" % src2)
check("第2轮有回答", ans2 is not None and len(ans2) > 10)
check("第2轮来源含QG_K002", "QG_K002" in src2, "来源=%s" % src2)

# 核心检查：第2轮回答不应包含苹果气调参数（氧气3%-5%是苹果的，不应出现在猕猴桃回答中）
pollution_markers = ["富士", "气调库", "氧气3", "氧气2", "二氧化碳0", "二氧化碳1"]
polluted = [m for m in pollution_markers if m in (ans2 or "")]
check("第2轮回答未被苹果气调污染", len(polluted) == 0,
      "污染标记=%s" % polluted)
# 第2轮应包含猕猴桃相关内容
kiwi_markers = ["猕猴桃", "上海", "催熟", "变甜"]
kiwi_hits = [m for m in kiwi_markers if m in (ans2 or "")]
check("第2轮回答包含猕猴桃催熟内容", len(kiwi_hits) >= 2,
      "命中=%s" % kiwi_hits)

print()
print("=" * 60)
print("测试B：正常追问验证（80mm价格 → '那75mm的呢'）")
print("=" * 60)
sessB = requests.Session()

q3 = "2026年1月80mm富士批发均价是多少？"
ans3, src3 = ask(sessB, q3)
print("第1轮问题: %s" % q3)
print("第1轮回答(前200字): %s" % (ans3[:200] if ans3 else "无回答"))
print("第1轮来源: %s" % src3)
check("追问第1轮有回答", ans3 is not None and len(ans3) > 10)
check("追问第1轮含4.89", "4.89" in (ans3 or ""), "回答未含4.89")

q4 = "那75mm的呢"
ans4, src4 = ask(sessB, q4)
print()
print("第2轮问题: %s" % q4)
print("第2轮回答(前300字): %s" % (ans4[:300] if ans4 else "无回答"))
print("第2轮来源: %s" % src4)
check("追问第2轮有回答", ans4 is not None and len(ans4) > 10)
check("追问第2轮含4.14", "4.14" in (ans4 or ""),
      "回答未含4.14，可能未理解指代")
check("追问第2轮理解了'75mm'指代", "75" in (ans4 or ""),
      "回答未提及75mm")

print()
print("=" * 60)
print("测试C：指代词场景（T20：'把你前面说的价格换成元/公斤'）")
print("=" * 60)
# sessB已有80mm价格上下文，继续追问单位换算
q5 = "把你前面说的2026年1月价格换成元/公斤"
ans5, src5 = ask(sessB, q5)
print("第3轮问题: %s" % q5)
print("第3轮回答(前300字): %s" % (ans5[:300] if ans5 else "无回答"))
check("指代词场景有回答", ans5 is not None and len(ans5) > 10)
# 换算后80mm应为9.78元/公斤
check("指代词场景含换算结果", "9.78" in (ans5 or "") or "公斤" in (ans5 or ""),
      "回答未含公斤换算")

print()
print("=" * 60)
print("总计：%d 通过，%d 失败" % (passed, failed))
print("=" * 60)
sys.exit(1 if failed else 0)