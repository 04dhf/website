# -*- coding: utf-8 -*-
"""测试多轮对话（上下文理解）和会话隔离，不输出任何密钥。"""
import re
import requests

BASE = "http://127.0.0.1:8080/consult"

def extract_bubbles(html):
    """从对话记录区提取所有气泡文本。"""
    bubbles = re.findall(r'<div class="chat-bubble bubble-(user|assistant)">(.*?)</div>', html, re.S)
    return [(role, re.sub(r'<[^>]+>', '', text).strip()) for role, text in bubbles]

print("=" * 60)
print("测试1：多轮对话 - 第二轮能否理解第一轮")
print("=" * 60)
sa = requests.Session()

# 第一轮
r1 = sa.post(BASE, data={"question": "洛川苹果有什么特点"}, timeout=60)
b1 = extract_bubbles(r1.text)
print(f"第一轮状态码: {r1.status_code}")
print(f"第一轮气泡数: {len(b1)}")
for role, text in b1:
    show = text[:80] + "..." if len(text) > 80 else text
    print(f"  [{role}] {show}")

# 第二轮：用"它"指代第一轮的洛川苹果
r2 = sa.post(BASE, data={"question": "它的采收期是什么时候"}, timeout=60)
b2 = extract_bubbles(r2.text)
print(f"\n第二轮状态码: {r2.status_code}")
print(f"第二轮气泡数: {len(b2)}")
last_answer = ""
for role, text in b2:
    show = text[:100] + "..." if len(text) > 100 else text
    print(f"  [{role}] {show}")
    if role == "assistant":
        last_answer = text

# 判断第二轮回答是否体现上下文（提到洛川/苹果/10月等）
ctx_keywords = ["洛川", "苹果", "10月", "十月", "下旬", "上旬", "霜降"]
hit = [k for k in ctx_keywords if k in last_answer]
if len(b2) == 4 and hit:
    print(f"\n✅ 多轮对话通过：第二轮共{len(b2)}条气泡（2轮），回答命中上下文关键词: {hit}")
else:
    print(f"\n❌ 多轮对话异常：气泡数={len(b2)}, 命中关键词={hit}")

print("\n" + "=" * 60)
print("测试2：会话隔离 - 新会话看不到旧会话历史")
print("=" * 60)
sb = requests.Session()
r3 = sb.post(BASE, data={"question": "翠香猕猴桃怎么催熟"}, timeout=60)
b3 = extract_bubbles(r3.text)
print(f"新会话状态码: {r3.status_code}")
print(f"新会话气泡数: {len(b3)}")
for role, text in b3:
    show = text[:80] + "..." if len(text) > 80 else text
    print(f"  [{role}] {show}")

leak = [t for r, t in b3 if "洛川" in t or "采收期" in t]
if len(b3) == 2 and not leak:
    print(f"\n✅ 会话隔离通过：新会话只有自己的{len(b3)}条气泡，无旧会话内容泄漏")
else:
    print(f"\n❌ 会话隔离异常：气泡数={len(b3)}, 泄漏内容={leak}")

print("\n" + "=" * 60)
print("测试3：清空对话")
print("=" * 60)
r4 = sa.post(BASE, data={"action": "clear"}, timeout=30)
b4 = extract_bubbles(r4.text)
print(f"清空后状态码: {r4.status_code}")
print(f"清空后气泡数: {len(b4)}")
if len(b4) == 0:
    print("✅ 清空对话通过：历史已清空")
else:
    print(f"❌ 清空对话异常：仍有{len(b4)}条气泡")