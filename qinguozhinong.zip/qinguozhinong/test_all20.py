# -*- coding: utf-8 -*-
"""运行test_questions.csv全部20道题，记录真实回答和通过情况。

分两部分报告：
1. 程序检查：HTTP状态、检索来源、回答非空
2. 模型回答评测：内容是否包含expected_behavior关键信息
"""
import csv
import html
import os
import re
import sys
import time
import requests

BASE = "http://127.0.0.1:8080"
CSV_PATH = os.path.join(os.path.dirname(__file__),
                        "qinguo_pack", "support", "test_questions.csv")


def extract_answer(page_html):
    """从consult页面HTML提取最后一条助手回答。"""
    bubbles = re.findall(
        r'class="chat-bubble bubble-assistant"[^>]*>(.*?)</div>',
        page_html, re.S)
    if not bubbles:
        return ""
    answer = bubbles[-1]
    answer = re.sub(r"<[^>]+>", "", answer)
    answer = html.unescape(answer)
    return answer.strip()


def extract_sources(html):
    """提取页面展示的来源ID。"""
    return sorted(set(re.findall(r"QG_[A-Z]\d+", html)))


def ask(sess, question, timeout=60):
    """向/consult发送问题，返回(回答, 来源, 状态码)。"""
    try:
        r = sess.post(BASE + "/consult", data={"question": question},
                      timeout=timeout)
    except requests.exceptions.Timeout:
        return "", [], 0
    if r.status_code != 200:
        return "", [], r.status_code
    return extract_answer(r.text), extract_sources(r.text), 200


# 每题的通过判定关键词（从expected_behavior提取）
# 格式：(必须包含的关键词列表, 不能包含的关键词列表)
EVAL_RULES = {
    "T01": (["4.89"], []),
    "T02": (["4.14", "5.32", "5.51"], []),
    "T03": ([], ["眉县"]),  # 应说没有今日数据，不能给出具体价格
    "T04": (["1.8", "4.5"], []),
    "T05": (["2.3", "5.5"], []),
    "T06": (["不是", "不"], ["4.75"]),  # 应否定4.75是官方均价
    "T07": (["相同", "一样", "相等", "等于"], []),
    "T08": ([], []),  # 应先问净重，人工判定
    "T09": (["不能", "不"], []),
    "T10": (["不能", "不", "无法"], []),
    "T11": ([], []),  # 应说明是发布日期，人工判定
    "T12": (["3%", "5%", "0%", "2%"], ["2%—4%", "1%—3%"]),
    "T13": (["不能", "不"], []),
    "T14": ([], []),  # 结合K001和K002解释，人工判定
    "T15": (["不能", "不"], []),
    "T16": (["不能", "不"], []),
    "T17": ([], []),  # 不编造排名，人工判定
    "T18": (["项目", "自定", "非政府", "不是.*标准"], []),
    "T19": ([], []),  # 询问成熟状态，人工判定
    "T20": (["8.28", "9.78", "公斤"], []),
}

# 需要人工重点判定的题目（程序关键词检查不够）
MANUAL_REVIEW = {"T03", "T08", "T09", "T11", "T14", "T17", "T19"}


def eval_answer(tid, answer):
    """根据关键词规则评测回答。返回(pass, reason)。"""
    must_have, must_not = EVAL_RULES.get(tid, ([], []))
    # 检查不能包含的关键词
    for kw in must_not:
        if kw in answer:
            return False, "包含不应出现的内容: %s" % kw
    # 检查必须包含的关键词
    missing = [kw for kw in must_have if kw not in answer]
    if missing:
        return False, "缺少关键信息: %s" % missing
    if tid in MANUAL_REVIEW:
        return True, "程序检查通过，需人工确认内容"
    return True, "关键词检查通过"


def main():
    with open(CSV_PATH, encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))

    results = []
    sess_main = requests.Session()  # T01和T20共用会话

    print("=" * 70)
    print("运行全部20道测试题（真实模型调用）")
    print("=" * 70)

    for row in rows:
        tid = row["id"]
        question = row["question"]
        expected = row["expected_behavior"]

        # T20复用T01的会话（依赖前面的价格上下文）
        if tid == "T20":
            sess = sess_main
        elif tid == "T01":
            sess = sess_main
        else:
            sess = requests.Session()

        print("\n[%s] %s" % (tid, question))
        print("  期望: %s" % expected[:80])

        t0 = time.time()
        answer, sources, code = ask(sess, question)
        elapsed = time.time() - t0

        # 程序检查
        prog_ok = code == 200 and len(answer) > 10
        prog_detail = "状态码=%d 回答长度=%d 来源=%s 耗时=%.1fs" % (
            code, len(answer), sources, elapsed)

        # 模型回答评测
        if prog_ok:
            eval_pass, eval_reason = eval_answer(tid, answer)
        else:
            eval_pass, eval_reason = False, "程序检查未通过"

        status = "PASS" if (prog_ok and eval_pass) else "FAIL"
        print("  [%s] %s" % (status, prog_detail))
        print("  评测: %s" % eval_reason)
        print("  回答(前150字): %s" % answer[:150].replace("\n", " "))

        results.append({
            "id": tid,
            "question": question,
            "expected": expected,
            "answer": answer[:500],
            "sources": ",".join(sources),
            "status_code": code,
            "prog_ok": prog_ok,
            "eval_pass": eval_pass,
            "eval_reason": eval_reason,
            "final": status,
        })

    # 汇总报告
    print("\n" + "=" * 70)
    print("汇总报告")
    print("=" * 70)
    prog_pass = sum(1 for r in results if r["prog_ok"])
    eval_pass = sum(1 for r in results if r["eval_pass"])
    final_pass = sum(1 for r in results if r["final"] == "PASS")
    print("程序检查: %d/20 通过" % prog_pass)
    print("模型评测: %d/20 通过" % eval_pass)
    print("综合判定: %d/20 通过" % final_pass)

    fails = [r for r in results if r["final"] == "FAIL"]
    if fails:
        print("\n失败题目:")
        for r in fails:
            print("  %s: %s" % (r["id"], r["eval_reason"]))

    # 写入CSV
    out_path = os.path.join(os.path.dirname(__file__),
                            "test_all20_results.csv")
    with open(out_path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["id", "question", "expected_behavior",
                    "actual_answer", "sources", "prog_ok",
                    "eval_pass", "final"])
        for r in results:
            w.writerow([r["id"], r["question"], r["expected"],
                        r["answer"], r["sources"], r["prog_ok"],
                        r["eval_pass"], r["final"]])
    print("\n详细结果已写入: %s" % out_path)

    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())