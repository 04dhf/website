# 秦果知农 - 配置文件
# ====================
# 大模型接口配置（OpenAI 兼容格式）
#
# 安全说明：正式密钥不随交付包分发。
# 部署时请在此处填入真实密钥，或通过环境变量注入，切勿提交到公开仓库。

# 大模型 API 地址（OpenAI 兼容）
LLM_API_URL = "https://open.bigmodel.cn/api/paas/v4/"

# 大模型 API 密钥 —— 请替换为你自己的密钥
LLM_API_KEY = "在此填入你的API密钥"

# 模型名称
LLM_MODEL_NAME = "glm-5.3-flash"

# 请求超时时间（秒）
LLM_TIMEOUT = 30