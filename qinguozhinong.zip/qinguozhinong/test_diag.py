# -*- coding: utf-8 -*-
"""诊断串题问题：检查检索词、检索片段、传给模型的历史。"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import app

app.reload_all_data()

print("=" * 60)
print("诊断1：两个问题的检索结果（检索本身是否正确）")
print("=" * 60)

q1 = "富士商业气调氧气2%—4%、二氧化碳1%—3%对吗？"
hits1 = app.search_docs(q1)
print("问题1: %s" % q1)
print("命中 %d 个块:" % len(hits1))
for h in hits1:
    print("  [%s] %s — %s (得分见排序)" % (h["source_id"], h["title"][:20], h["section"]))

print()
q2 = "所有陕西猕猴桃都能按上海案例3天变甜吗？"
hits2 = app.search_docs(q2)
print("问题2: %s" % q2)
print("命中 %d 个块:" % len(hits2))
for h in hits2:
    print("  [%s] %s — %s" % (h["source_id"], h["title"][:20], h["section"]))

print()
print("=" * 60)
print("诊断2：两个问题之间的 2-gram 相关性（话题是否切换）")
print("=" * 60)
g1 = app._char_ngrams(q1)
g2 = app._char_ngrams(q2)
overlap = g1 & g2
print("问题1 2-gram数: %d" % len(g1))
print("问题2 2-gram数: %d" % len(g2))
print("交集大小: %d" % len(overlap))
print("交集内容: %s" % sorted(overlap) if overlap else "空（话题已切换）")

print()
print("=" * 60)
print("诊断3：正常追问的相关性（'那75mm的呢'）")
print("=" * 60)
q3 = "2026年1月80mm富士批发均价多少"
q4 = "那75mm的呢"
g3 = app._char_ngrams(q3)
g4 = app._char_ngrams(q4)
overlap2 = g3 & g4
print("问题3: %s" % q3)
print("问题4: %s" % q4)
print("交集大小: %d" % len(overlap2))
print("交集内容: %s" % sorted(overlap2) if overlap2 else "空")
print("问题4包含指代词'那': %s" % ("那" in q4))

print()
print("=" * 60)
print("诊断4：当前传给模型的消息结构（模拟串题场景）")
print("=" * 60)
# 模拟：第一轮问气调，第二轮问猕猴桃催熟
history = [
    {"role": "user", "content": q1},
    {"role": "assistant", "content": "根据参考资料，富士系商业气调参考为氧气3%—5%、二氧化碳0%—2%..."},
]
print("当前行为：ask_llm(q2, history, context=QG_K002检索结果)")
print("  → 消息列表: [system, system(参考资料), user(q1), assistant(气调回答), user(q2)]")
print("  → 问题：history中气调问答会干扰模型对猕猴桃问题的回答")
print()
print("期望行为：检测到q2与q1话题不相关且无指代词 → 不传history")
print("  → 消息列表: [system, system(参考资料-QG_K002), user(q2)]")