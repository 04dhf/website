# -*- coding: utf-8 -*-
"""阶段4验证脚本：测试报价检查的多种场景"""
import urllib.request
import urllib.parse

BASE = "http://127.0.0.1:8080/quote"

def post_quote(data):
    """提交表单并返回 (状态码, 页面内容)"""
    encoded = urllib.parse.urlencode(data).encode("utf-8")
    req = urllib.request.Request(BASE, data=encoded, method="POST")
    try:
        r = urllib.request.urlopen(req)
        return r.status, r.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8")

def check(name, data, expect_conclusion, expect_text=None):
    """提交并检查结论是否正确"""
    status, body = post_quote(data)
    ok = status == 200 and expect_conclusion in body
    if expect_text:
        ok = ok and expect_text in body
    print(("PASS" if ok else "FAIL"), "|", name, "| status:", status, "| 结论含「%s」: %s" % (expect_conclusion, expect_conclusion in body))
    return ok

# 场景1：苹果·洛川·半商品·产地收购价 3.5 → 可比（精确产地+同规格）
check("苹果洛川半商品3.5", {
    "product_type": "apple", "product_name": "晚富士苹果",
    "origin": "陕西·延安·洛川", "spec": "70#起步 半商品",
    "price": "3.5", "price_stage": "产地收购价", "quantity": "", "quote_date": "",
}, "可比", "3.5")

# 场景2：苹果·洛川·统货·产地收购价 2.5 → 部分可比（产地匹配但规格不同）
check("苹果洛川统货2.5", {
    "product_type": "apple", "product_name": "晚富士苹果",
    "origin": "陕西·延安·洛川", "spec": "70#以上 统货",
    "price": "2.5", "price_stage": "产地收购价", "quantity": "", "quote_date": "",
}, "部分可比", "等级不同")

# 场景3：苹果·批发市场价 → 不可比（无苹果批发数据）
check("苹果批发环节", {
    "product_type": "apple", "product_name": "晚富士苹果",
    "origin": "陕西·西安", "spec": "批发价",
    "price": "4.0", "price_stage": "批发市场价", "quantity": "", "quote_date": "",
}, "不可比")

# 场景4：猕猴桃·眉县·产地收购价 3.2 → 可比（精确产地+同环节+规格不冲突，价格解析"约3元多"→3.0~3.9）
check("猕猴桃眉县产地3.2", {
    "product_type": "kiwi", "product_name": "徐香猕猴桃",
    "origin": "陕西·眉县", "spec": "地头收购（客商进园）",
    "price": "3.2", "price_stage": "产地收购价", "quantity": "", "quote_date": "",
}, "可比")

# 场景5：猕猴桃·批发市场价 4.5 → 部分可比（外省批发市场对照）
check("猕猴桃批发4.5", {
    "product_type": "kiwi", "product_name": "猕猴桃（综合）",
    "origin": "陕西·西安", "spec": "批发价",
    "price": "4.5", "price_stage": "批发市场价", "quantity": "", "quote_date": "",
}, "部分可比")

# 场景6：缺必填字段 → 错误提示
status, body = post_quote({"product_type": "apple", "origin": "", "spec": "", "price": "", "price_stage": ""})
ok = status == 200 and "必填项" in body
print(("PASS" if ok else "FAIL"), "| 缺必填字段 | status:", status, "| 有错误提示:", "必填项" in body)

# 场景7：单价非数字 → 错误提示
status, body = post_quote({"product_type": "apple", "origin": "洛川", "spec": "统货", "price": "abc", "price_stage": "产地收购价"})
ok = status == 200 and "必须是数字" in body
print(("PASS" if ok else "FAIL"), "| 单价非数字 | status:", status, "| 有错误提示:", "必须是数字" in body)

print("\n验证完成。")