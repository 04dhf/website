# -*- coding: utf-8 -*-
"""测试资料导入与检索功能：导入/切分/检索/去重/重载，不依赖网络。"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import app

PASS = 0
FAIL = 0

def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  ✅ %s" % name)
    else:
        FAIL += 1
        print("  ❌ %s %s" % (name, detail))

print("=" * 60)
print("测试1：导入文档（data/docs/ 下 1 篇真实示例 + 1 篇_说明不导入）")
print("=" * 60)
stats = app.reload_all_data()
check("导入文档数 = 1", stats["docs"] == 1, "实际 %d" % stats["docs"])
check("检索块数 = 5（概述+4个小节）", stats["chunks"] == 5, "实际 %d" % stats["chunks"])
check("DOCS_META 有 1 条", len(app.DOCS_META) == 1)
check("CSV 行情 = 0（_说明文件不导入）", stats["csv_rows"] == 0, "实际 %d" % stats["csv_rows"])

meta = app.DOCS_META[0] if app.DOCS_META else {}
print("  文档元数据：source_id=%s, title=%s, publisher=%s, date=%s, product=%s, scene=%s"
      % (meta.get("source_id"), meta.get("title"), meta.get("publisher"),
         meta.get("date"), meta.get("product"), meta.get("scene")))
check("元数据字段完整",
      all(k in meta for k in ("source_id", "title", "publisher",
                              "source_url", "date", "product", "scene")))

print()
print("=" * 60)
print("测试2：中文检索 - 命中相关小节")
print("=" * 60)
hits = app.search_docs("苹果怎么储存保鲜")
check("检索有结果", len(hits) > 0, "结果数 %d" % len(hits))
for h in hits:
    print("    [得分隐藏] 《%s》— %s" % (h["title"], h["section"]))
sections = [h["section"] for h in hits]
check("命中'家庭储存方法'小节", "家庭储存方法" in sections, str(sections))
check("命中'冷库储存要点'小节", "冷库储存要点" in sections, str(sections))
check("每块带完整来源元数据",
      all("source_id" in h and "title" in h and "publisher" in h for h in hits))
check("返回结果不含内部字段 _grams",
      all("_grams" not in h for h in hits))

hits2 = app.search_docs("红富士耐不耐储存")
check("换问法也能命中", len(hits2) > 0)
if hits2:
    print("    命中小节：%s" % [h["section"] for h in hits2])

hits3 = app.search_docs("今天天气怎么样")
check("无关问题无命中（不硬凑）", len(hits3) == 0, "命中 %d 条" % len(hits3))

print()
print("=" * 60)
print("测试3：重复加载不产生重复记录")
print("=" * 60)
app.reload_all_data()
app.reload_all_data()
check("连续加载3次后文档仍为 1 篇", len(app.DOCS_META) == 1, "实际 %d" % len(app.DOCS_META))
check("检索块仍为 5 个", len(app.DOC_CHUNKS) == 5, "实际 %d" % len(app.DOC_CHUNKS))

print()
print("=" * 60)
print("测试4：CSV 行情导入与去重")
print("=" * 60)
# 临时创建测试 CSV（测试后删除）
test_csv = os.path.join(app.MARKET_CSV_DIR, "test_temp.csv")
with open(test_csv, "w", encoding="utf-8-sig", newline="") as f:
    f.write("source_id,product,variety,grade,region,stage,date,price,unit\n")
    f.write("SRC-T01,苹果,红富士,80mm起,陕西·延安·洛川,产地收购价,2026-10-20,3.5,元/斤\n")
    f.write("SRC-T01,苹果,红富士,80mm起,陕西·延安·洛川,产地收购价,2026-10-20,3.5,元/斤\n")
    f.write("SRC-T02,猕猴桃,翠香,统货,陕西·西安·周至,产地收购价,2026-10-15,4.0,元/斤\n")
try:
    stats2 = app.reload_all_data()
    check("CSV 导入 2 条（同指纹去重后）", stats2["csv_rows"] == 2, "实际 %d" % stats2["csv_rows"])
    apple_csv = [r for r in app.CSV_MARKET_ROWS if r["_type"] == "apple"]
    kiwi_csv = [r for r in app.CSV_MARKET_ROWS if r["_type"] == "kiwi"]
    check("苹果 CSV 1 条", len(apple_csv) == 1)
    check("猕猴桃 CSV 1 条", len(kiwi_csv) == 1)
    row = apple_csv[0]
    check("字段适配：category=产地收购价", row["category"] == "产地收购价", row["category"])
    check("字段适配：origin=地区", "洛川" in row["origin"], row["origin"])
    check("字段适配：spec=规格", "80mm" in row["spec"], row["spec"])
    check("字段适配：price含单位", "3.5 元/斤" == row["price"], row["price"])
    check("字段适配：source含来源编号", "SRC-T01" in row["source"], row["source"])
    # 再次加载，确认不重复
    app.reload_all_data()
    check("再次加载 CSV 仍为 2 条", len(app.CSV_MARKET_ROWS) == 2,
          "实际 %d" % len(app.CSV_MARKET_ROWS))
finally:
    os.remove(test_csv)
app.reload_all_data()  # 清理后重新加载
check("删除测试CSV后行情归 0", len(app.CSV_MARKET_ROWS) == 0)

print()
print("=" * 60)
print("测试5：无资料时检索返回空")
print("=" * 60)
saved_chunks = app.DOC_CHUNKS[:]
app.DOC_CHUNKS = []
check("无资料时检索返回空列表", app.search_docs("苹果") == [])
app.DOC_CHUNKS = saved_chunks  # 恢复

print()
print("=" * 60)
print("结果：%d 通过，%d 失败" % (PASS, FAIL))
print("=" * 60)
sys.exit(1 if FAIL else 0)