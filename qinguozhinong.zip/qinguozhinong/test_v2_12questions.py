# -*- coding: utf-8 -*-
"""
V2 新增12题验证：逐题真实调用，记录回答/来源/延迟/判定。
按顺序在同一 session 中执行（V2_08→V2_09 为指代对，V2_12 依赖价格上下文）。
结果写入 test_v2_12results.csv，控制台输出摘要。
"""
import csv
import re
import time
import requests

BASE = 'http://127.0.0.1:8080/consult'

# 12道题 + 判定函数（返回 通过/未通过/人工复核 + 原因）
QUESTIONS = [
    ('V2_01', '苹果表面亮亮的，能凭照片确定是工业蜡吗？',
     ['QG_A004'],
     lambda a, s: ('通过', '明确不能凭照片判定') if ('不能' in a or '无法' in a)
     and 'QG_A004' in s else ('未通过', '未明确否定或来源不对')),
    ('V2_02', '父母喜欢绵软口感，富士和花牛如何选？',
     ['QG_A003'],
     lambda a, s: ('通过', '给了口感方向') if ('花牛' in a and '绵' in a)
     and 'QG_A003' in s else ('未通过', '未给口感方向或来源不对')),
    ('V2_03', '苹果长了霉，切掉一块剩下可以吃吗？',
     ['QG_A003'],
     lambda a, s: ('通过', '不作切除后安全保证') if ('不建议' in a or '丢弃' in a or '不能保证' in a or '不要' in a)
     and 'QG_A003' in s else ('未通过', '未给出安全建议或来源不对')),
    ('V2_04', '整箱苹果想多放几天，要和硬猕猴桃一起装吗？',
     ['QG_A002'],
     lambda a, s: ('通过', '区分保存与催熟') if ('乙烯' in a or '分开' in a or '催熟' in a)
     and 'QG_A002' in s else ('未通过', '未区分保存催熟或来源不对')),
    ('V2_05', '请说NY/T 983-2015第5条的具体温度',
     ['QG_S001'],
     lambda a, s: ('通过', '仅目录不编造条文') if ('目录' in a or '没有全文' in a or '无法提供' in a or '未收录' in a or '不编造' in a)
     and 'QG_S001' in s else ('未通过', '可能编造了条文或来源不对')),
    ('V2_06', '2026年2月猕猴桃出库均价3.9元吗？',
     ['QG_M004'],
     lambda a, s: ('通过', '区间而非中点均价') if ('2.4' in a and '5.4' in a)
     and 'QG_M004' in s else ('未通过', '未给区间或来源不对')),
    ('V2_07', '2025年10月海沃德、徐香批发监测均价各是多少？',
     ['QG_M005'],
     lambda a, s: ('通过', '4.88和4.91元/斤') if ('4.88' in a and '4.91' in a)
     and 'QG_M005' in s else ('未通过', '数字不对或来源不对')),
    ('V2_08', '2025年10月海南南北与南京众彩翠香报价差多少？',
     ['QG_M005'],
     lambda a, s: ('通过', '10.00/3.90/名义差') if ('10' in a and '3.9' in a and '6.1' in a)
     and 'QG_M005' in s else ('未通过', '数字不对或来源不对')),
    ('V2_09', '把南京那个换成元/公斤',
     ['QG_M005'],
     lambda a, s: ('通过', '7.80元/公斤非海南') if '7.8' in a and 'QG_M005' in s and '10' not in a.split('7.8')[0][-30:]
     else ('人工复核', '需确认未混淆海南报价')),
    ('V2_10', '2026年10月南京翠香也一定是3.9吗？',
     [],
     lambda a, s: ('通过', '不沿用2025-10数据') if ('没有' in a or '无法' in a or '不能' in a or '不确定' in a)
     else ('未通过', '可能错误沿用了旧数据')),
    ('V2_11', '宝鸡2023年资料可以直接确定我今年停水天数吗？',
     ['QG_K004'],
     lambda a, s: ('通过', '不给固定天数') if ('不能' in a or '无法' in a or '不确定' in a)
     and 'QG_K004' in s else ('未通过', '给了固定天数或来源不对')),
    ('V2_12', '这6条猕猴桃价格能连成6个月的走势吗？',
     [],
     lambda a, s: ('通过', '不能连走势') if ('不能' in a or '无法' in a)
     and ('同一月' in a or '不同品种' in a or '不同市场' in a or '口径' in a or '混合' in a)
     else ('人工复核', '需确认拒绝原因是否合理')),
]


def ask(s, q):
    t0 = time.time()
    r = s.post(BASE, data={'question': q}, timeout=90)
    dt = round(time.time() - t0, 1)
    t = r.text
    bubbles = re.findall(r'bubble-assistant[^>]*>(.*?)</div>\s*</div>', t, re.S)
    ans = re.sub(r'<[^>]+>', ' ', bubbles[-1]).strip() if bubbles else ''
    ans = re.sub(r'\s+', ' ', ans)
    sids = re.findall(r'rag-sid">(QG_[A-Z0-9]+)</span>', t)
    return ans, sids, dt


def main():
    s = requests.Session()
    rows = []
    pass_count = 0
    for qid, question, expect_src, judge in QUESTIONS:
        ans, sids, dt = ask(s, question)
        verdict, reason = judge(ans, ','.join(sids))
        if verdict == '通过':
            pass_count += 1
        src_ok = all(e in sids for e in expect_src) if expect_src else True
        row = {
            'id': qid, 'question': question,
            'answer': ans, 'sources': ','.join(sids),
            'latency_s': dt, 'verdict': verdict, 'reason': reason,
            'src_ok': '是' if src_ok else '否',
        }
        rows.append(row)
        print(f"{qid} [{verdict}] {dt}s 来源:{sids}")
        print(f"  答: {ans[:120]}")
        print(f"  判: {reason}")
        print()

    with open('test_v2_12results.csv', 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['id', 'question', 'answer', 'sources',
                                          'latency_s', 'verdict', 'reason', 'src_ok'])
        w.writeheader()
        w.writerows(rows)

    print(f'总计: {pass_count}/12 通过，结果已写入 test_v2_12results.csv')


if __name__ == '__main__':
    main()