# -*- coding: utf-8 -*-
"""最终验证：页面展示/日期/链接/工具/多轮对话。"""
import re
import requests

PASS = 0
FAIL = 0

def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  ✅ %s" % name)
    else:
        FAIL += 1
        print("  ❌ %s %s" % (name, detail))

print("=" * 60)
print("测试1：知识库页展示8篇文档+链接")
print("=" * 60)
r = requests.get("http://127.0.0.1:8080/knowledge", timeout=10)
html = r.text
check("状态码200", r.status_code == 200)
check("统计显示8篇文档", re.findall(r"已导入文档 <b>(\d+)</b>", html) == ["8"])
check("统计显示4条CSV", re.findall(r"行情 CSV <b>(\d+)</b>", html) == ["4"])
for sid in ("QG_A001", "QG_K001", "QG_K002", "QG_K003",
            "QG_M001", "QG_M002", "QG_M003", "QG_R001"):
    check("显示 %s" % sid, sid in html)
check("显示来源链接（https）", html.count('href="https://') >= 8)
check("QG_R001标注非政府标准", "非政府" in html)
check("演示文件未展示", "SRC-2026-001" not in html)

print()
print("=" * 60)
print("测试2：行情页展示CSV数据+月报日期")
print("=" * 60)
r2 = requests.get("http://127.0.0.1:8080/market", timeout=10)
html2 = r2.text
check("状态码200", r2.status_code == 200)
check("显示4.89元/斤", "4.89 元/斤" in html2 or "4.89元/斤" in html2)
check("显示4.14元/斤", "4.14 元/斤" in html2 or "4.14元/斤" in html2)
check("日期显示2026-01（非2026-01-01）", "2026-01" in html2 and "2026-01-01" not in html2)
check("显示月报口径", "月报口径" in html2)
check("显示来源编号QG_M001", "QG_M001" in html2)
check("原有JSON行情仍在（洛川）", "洛川" in html2)

print()
print("=" * 60)
print("测试3：报价工具不受破坏")
print("=" * 60)
r3 = requests.get("http://127.0.0.1:8080/quote", timeout=10)
check("报价页200", r3.status_code == 200)
r4 = requests.get("http://127.0.0.1:8080/compare", timeout=10)
check("对比页200", r4.status_code == 200)
# 提交一条报价测试
r5 = requests.post("http://127.0.0.1:8080/quote", data={
    "product_type": "apple", "product_name": "晚富士",
    "origin": "陕西·延安·洛川", "spec": "70#起步 半商品",
    "quantity": "1000", "price": "3.5", "price_stage": "产地收购价",
    "quote_date": "2026-10-30",
}, timeout=10)
check("报价提交200", r5.status_code == 200)
check("报价有结论", "可比" in r5.text or "部分可比" in r5.text or "不可比" in r5.text)

print()
print("=" * 60)
print("测试4：多轮对话+RAG来源展示")
print("=" * 60)
s = requests.Session()
r6 = s.post("http://127.0.0.1:8080/consult",
            data={"question": "2026年1月80mm富士批发均价多少"}, timeout=90)
check("第一轮200", r6.status_code == 200)
check("第一轮有参考来源", 'class="rag-sources card"' in r6.text)
check("来源含QG_M001", "QG_M001" in r6.text)
check("回答含4.89", "4.89" in r6.text)
# 第二轮：上下文跟踪
r7 = s.post("http://127.0.0.1:8080/consult",
            data={"question": "那75mm的呢"}, timeout=90)
check("第二轮200", r7.status_code == 200)
check("第二轮理解'75mm'指代", "4.14" in r7.text)

print()
print("=" * 60)
print("结果：%d 通过，%d 失败" % (PASS, FAIL))
print("=" * 60)