# -*- coding: utf-8 -*-
"""最终验证：行情页/对比页正常 + RAG回答引用资料细节。"""
import re
import requests

s = requests.Session()

# 1. 行情页正常（无CSV数据时展示json数据不受影响）
r = requests.get("http://127.0.0.1:8080/market", timeout=30)
print("market 状态码:", r.status_code)
print("行情页有苹果数据:", "洛川" in r.text)
print("行情页免责声明:", "免责" in r.text or "仅供参考" in r.text)

# 2. 报价对比页正常
r2 = requests.get("http://127.0.0.1:8080/compare", timeout=30)
print("\ncompare GET 状态码:", r2.status_code)

# 3. 报价检查页正常
r3 = requests.get("http://127.0.0.1:8080/quote", timeout=30)
print("quote GET 状态码:", r3.status_code)

# 4. RAG回答质量：气调库浓度细节只在导入文档中（氧气2%-4%，二氧化碳1%-3%）
r4 = s.post("http://127.0.0.1:8080/consult",
            data={"question": "气调库储存苹果时氧气和二氧化碳浓度控制在多少"},
            timeout=60)
html = r4.text
print("\nRAG细节问题状态码:", r4.status_code)
print("展示参考来源:", 'class="rag-sources card"' in html)
# 提取助手最新回答
answers = re.findall(r'bubble-assistant">(.*?)</div>', html, re.S)
last = answers[-1].strip() if answers else ""
# 检查回答是否包含文档独有细节
hit_o2 = "2%" in last and "4%" in last
hit_co2 = "1%" in last and "3%" in last
print("回答含氧气浓度2%-4%:", hit_o2)
print("回答含二氧化碳浓度1%-3%:", hit_co2)
print("回答片段:", re.sub(r'<[^>]+>', '', last)[:150].strip(), "...")