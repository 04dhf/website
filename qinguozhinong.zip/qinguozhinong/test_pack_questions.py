# -*- coding: utf-8 -*-
"""按 support/test_questions.csv 逐项核验，报告实际结果，不预填通过。"""
import re
import requests

BASE = "http://127.0.0.1:8080/consult"
results = []

def ask(session, question):
    """提问并返回（助手回答文本, 来源编号列表）。"""
    r = session.post(BASE, data={"question": question}, timeout=90)
    answers = re.findall(r'bubble-assistant">(.*?)</div>', r.text, re.S)
    srcs = re.findall(r'rag-sid">(.*?)</span>', r.text)
    last = re.sub(r'<[^>]+>', '', answers[-1]).strip() if answers else ""
    return last, srcs, r.status_code

def record(tid, question, expected, actual, passed):
    results.append((tid, question, expected, actual, passed))
    mark = "✅" if passed else "❌"
    print("%s %s" % (mark, tid))
    print("   问: %s" % question)
    print("   期望: %s" % expected)
    print("   实际: %s" % actual[:200])
    print()

s = requests.Session()

# ---- T01: 80mm批发监测均价 ----
ans, srcs, code = ask(s, "2026年1月陕西富士80mm批发监测均价是多少？")
ok = "4.89" in ans and "QG_M001" in srcs
record("T01", "80mm批发监测均价", "4.89元/斤；来源QG_M001", ans, ok)

# ---- T02: 75/85/90mm 均价 ----
ans2, srcs2, _ = ask(s, "2026年1月75mm、85mm、90mm富士均价分别是多少？")
ok2 = "4.14" in ans2 and "5.32" in ans2 and "5.51" in ans2
record("T02", "75/85/90mm均价", "4.14、5.32、5.51元/斤", ans2, ok2)

# ---- T03: 今日眉县翠香收购价（无数据） ----
ans3, srcs3, _ = ask(s, "今天眉县翠香收购价是多少？")
ok3 = ("没有" in ans3 or "无" in ans3 or "暂" in ans3 or "尚" in ans3
       or "历史" in ans3 or "不足" in ans3)
record("T03", "今日眉县翠香收购价", "无今日数据，不得用历史区间顶替", ans3, ok3)

# ---- T04: 2026年3月宝鸡富士出库价 ----
ans4, srcs4, _ = ask(s, "2026年3月宝鸡富士出库价是多少？")
ok4 = ("1.8" in ans4 and "4.5" in ans4) or ("1.8—4.5" in ans4)
record("T04", "3月宝鸡富士出库价", "1.8—4.5元/斤，QG_M002", ans4, ok4)

# ---- T06: 猕猴桃均价4.75？ ----
ans6, _, _ = ask(s, "2026年1月猕猴桃均价是不是4.75元/斤？")
ok6 = "4.75" not in ans6 or "不是" in ans6 or "区间" in ans6
record("T06", "猕猴桃均价4.75？", "不是；4.5—5为区间，4.75非官方均价", ans6, ok6)

# ---- T10: 4条行情能画走势图？ ----
ans10, _, _ = ask(s, "这4条苹果行情能画逐日走势图吗？")
ok10 = "不能" in ans10 or "不可以" in ans10
record("T10", "4条行情画走势图？", "不能；同一月份不同规格", ans10, ok10)

# ---- T12: 气调参数核验（关键：演示值vs原文值） ----
ans12, srcs12, _ = ask(s, "富士商业气调氧气2%—4%、二氧化碳1%—3%对吗？")
ok12 = ("3%" in ans12 and "5%" in ans12) or ("0%" in ans12 and "2%" in ans12) or "不对" in ans12 or "不是" in ans12
record("T12", "气调氧气2%-4%对吗？", "QG_A001原文为3%—5%、0%—2%，不能沿用演示值", ans12, ok12)

# ---- T15: 上海案例3天变甜？ ----
ans15, _, _ = ask(s, "所有陕西猕猴桃都能按上海案例3天变甜吗？")
ok15 = "不能" in ans15 or "不可以" in ans15
record("T15", "陕西猕猴桃按上海案例3天变甜？", "不能；地域品种环境限制", ans15, ok15)

# ---- T18: QG_R001是政府标准？ ----
ans18, _, _ = ask(s, "请给出农业部发布的QG_R001标准")
ok18 = "项目" in ans18 and ("非政府" in ans18 or "不是政府" in ans18 or "非标准" in ans18 or "自定义" in ans18)
record("T18", "QG_R001是农业部标准？", "QG_R001为项目自定规则，非政府标准", ans18, ok18)

# ---- 汇总 ----
passed = sum(1 for r in results if r[4])
total = len(results)
print("=" * 60)
print("测试题目核验结果：%d/%d 通过" % (passed, total))
print("=" * 60)
for tid, q, exp, act, ok in results:
    print("%s %s" % ("✅" if ok else "❌", tid))